const afkStorage = global.afkStorage || (global.afkStorage = new Map());
const afkCooldown = global.afkCooldown || (global.afkCooldown = new Map());

const pluginConfig = {
  name: "afk",
  alias: ["away", "brb"],
  category: "group",
  description: "Set status AFK dengan alasan",
  usage: ".afk <alasan>",
  example: ".afk lagi makan",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 5,
  energi: 0,
  isEnabled: true,
};

function getAfkUser(jid) {
  return afkStorage.get(jid) || null;
}

function setAfkUser(jid, reason) {
  afkStorage.set(jid, {
    reason: reason || "Tidak ada alasan",
    time: Date.now(),
  });
}

function removeAfkUser(jid) {
  afkStorage.delete(jid);
}

function isUserAfk(jid) {
  return afkStorage.has(jid);
}

function formatDuration(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  if (hours > 0) return `${hours} jam ${minutes % 60} menit`;
  if (minutes > 0) return `${minutes} menit ${seconds % 60} detik`;
  return `${seconds} detik`;
}

function buildMessage(text, mentions = [], botConfig = {}) {
  const saluranId = botConfig?.saluran?.id || "120363409557700746@newsletter";
  const saluranName = botConfig?.saluran?.name || botConfig?.bot?.name || "Bot";
  const botName = botConfig?.bot?.name || "Bot";

  return {
    text,
    mentions,
    footer: `© ${botName}`,
    buttons: [
      {
        buttonId: "lihat_saluran",
        buttonText: { displayText: "Lihat Saluran" },
        type: 1,
      },
    ],
    headerType: 1,
    contextInfo: {
      mentionedJid: mentions,
      forwardingScore: 9999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: saluranId,
        newsletterName: saluranName,
        serverMessageId: 127,
      },
    },
  };
}

async function handler(m, { sock, config: botConfig }) {
  const reason = m.text || "Tidak ada alasan";
  setAfkUser(m.sender, reason);

  const num = m.sender.split("@")[0];
  const text =
    `✦ *mode afk aktif*\n\n` +
    `hei, @${num} lagi nggak ada sebentar~\n` +
    `╰┈➤ *${reason}*`;

  await sock.sendMessage(m.chat, buildMessage(text, [m.sender], botConfig), { quoted: m });
}

async function checkAfk(m, sock, botConfig = {}, isJadibot = false) {
  
  const instanceKey = isJadibot ? "jadibot" : "main";
  const msgKey = `${instanceKey}_${m.chat}_${m.sender}_${m.id || Date.now()}`;
  if (afkCooldown.has(msgKey)) return;
  afkCooldown.set(msgKey, Date.now());

  if (afkCooldown.size > 200) {
    const cutoff = Date.now() - 10000;
    for (const [k, v] of afkCooldown) {
      if (v < cutoff) afkCooldown.delete(k);
    }
  }

  const wasAfkKey = `wasAfk_${m.sender}`;
  const jadibotSentKey = `jadibotSent_${m.sender}`;

  if (isJadibot) {
    
    await new Promise((r) => setTimeout(r, 2000));

    if (global[wasAfkKey] && !global[jadibotSentKey]) {
      global[jadibotSentKey] = true;
      
      setTimeout(() => { delete global[jadibotSentKey]; }, 5000);

      const num = m.sender.split("@")[0];
      const text =
        `✦ *welcome back!*\n\n` +
        `@${num} udah balik nih~`;
      await sock.sendMessage(m.chat, buildMessage(text, [m.sender], botConfig), { quoted: m });
    }
    return; 
  }

  const notified = new Set();

  const afkData = getAfkUser(m.sender);
  if (afkData) {
    const isAfkCmd =
      m.body?.startsWith?.(".afk") ||
      m.body?.startsWith?.("/afk") ||
      m.body?.startsWith?.("!afk");
    if (isAfkCmd) return;

    removeAfkUser(m.sender);

    global[wasAfkKey] = true;
    global[jadibotSentKey] = false;
    setTimeout(() => {
      delete global[wasAfkKey];
      delete global[jadibotSentKey];
    }, 10000);

    notified.add(m.sender);
    const duration = formatDuration(Date.now() - afkData.time);
    const num = m.sender.split("@")[0];
    const text =
      `✦ *welcome back!*\n\n` +
      `@${num} udah balik nih~\n` +
      `╰┈➤ afk selama *${duration}*`;

    await sock.sendMessage(m.chat, buildMessage(text, [m.sender], botConfig), { quoted: m });
  }

  if (m.isGroup && m.mentionedJid && m.mentionedJid.length > 0) {
    for (const mentioned of m.mentionedJid) {
      if (notified.has(mentioned)) continue;
      const mentionedAfk = getAfkUser(mentioned);
      if (!mentionedAfk) continue;

      const duration = formatDuration(Date.now() - mentionedAfk.time);
      const num = mentioned.split("@")[0];
      const text =
        `✦ *psst, dia lagi afk*\n\n` +
        `@${num} lagi nggak bisa diganggu dulu~\n` +
        `╰┈➤ alasan: *${mentionedAfk.reason}*\n` +
        `╰┈➤ sudah pergi sejak *${duration} lalu*`;

      await sock.sendMessage(m.chat, buildMessage(text, [mentioned], botConfig), { quoted: m });
      notified.add(mentioned);
    }
  }

  if (m.isGroup && m.quoted) {
    const quotedSender = m.quoted.sender || m.quoted.participant || null;
    if (quotedSender && quotedSender !== m.sender && !notified.has(quotedSender)) {
      const quotedAfk = getAfkUser(quotedSender);
      if (quotedAfk) {
        const duration = formatDuration(Date.now() - quotedAfk.time);
        const num = quotedSender.split("@")[0];
        const text =
          `✦ *eh, dia lagi afk lho*\n\n` +
          `@${num} yang kamu quote lagi nggak ada nih~\n` +
          `╰┈➤ alasan: *${quotedAfk.reason}*\n` +
          `╰┈➤ sudah pergi sejak *${duration} lalu*`;

        await sock.sendMessage(m.chat, buildMessage(text, [quotedSender], botConfig), { quoted: m });
        notified.add(quotedSender);
      }
    }
  }
}

export {
  pluginConfig as config,
  handler,
  checkAfk,
  getAfkUser,
  setAfkUser,
  removeAfkUser,
  isUserAfk,
};