import te from "../../src/lib/ichigo-error.js";
import ichigoApi from "../../src/lib/ichigo-apimanager.js";
const pluginConfig = {
  name: "gpt4o",
  alias: ["gpt4"],
  category: "ai",
  description: "Chat dengan GPT-4o",
  usage: ".gpt4o <pertanyaan>",
  example: ".gpt4o Hai apa kabar?",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 5,
  energi: 1,
  isEnabled: true,
};

async function handler(m, { sock }) {
  const text = m.args.join(" ");
  if (!text) {
    return m.reply(
      `🧠 *ɢᴘᴛ-4ᴏ*\n\n> Masukkan pertanyaan\n\n\`Contoh: ${m.prefix}gpt4o Hai apa kabar?\``,
    );
  }

  m.react("🕕");

  try {
    const data = await ichigoApi.covenant.gpt4(text);

    m.react("✅");
    await m.reply(`${data.data.result}`);
  } catch (error) {
    console.log(error);
    m.react("☢");
    m.reply(te(m.prefix, m.command, m.pushName));
  }
}

export { pluginConfig as config, handler };
