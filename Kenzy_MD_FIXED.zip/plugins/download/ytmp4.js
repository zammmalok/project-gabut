const pluginConfig = {
  name: "ytmp4",
  alias: ["youtubemp4", "ytvideo"],
  category: "download",
  description: "Download video YouTube",
  usage: ".ytmp4 <url> [144|240|360|480|720|1080]",
  example: ".ytmp4 https://youtube.com/watch?v=xxx 480",
  cooldown: 20,
  energi: 2,
  isEnabled: true,
};

const API_URL = "https://api-cloud.my.id/download/ytmp4";
const API_TIMEOUT = 45000;
const RESOLUTIONS = ["144", "240", "360", "480", "720", "1080"];

async function fetchFromApi(url, resolution) {
  const endpoint = `${API_URL}?url=${encodeURIComponent(url)}&quality=${resolution}p`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), API_TIMEOUT);

  try {
    const res = await fetch(endpoint, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`API HTTP ${res.status}`);

    const data = await res.json();
    const r = data?.result;
    if (!data?.status || !r?.downloadUrl) {
      throw new Error(data?.error || data?.message || "API tidak mengembalikan link download");
    }

    return {
      download: r.downloadUrl,
      title: r.title,
    };
  } finally {
    clearTimeout(timer);
  }
}

async function handler(m, { sock }) {
  const args = (m.text || "").trim().split(/\s+/).filter(Boolean);
  const url = args[0];
  if (!url)
    return m.reply(`Contoh: ${m.prefix}ytmp4 https://youtube.com/watch?v=xxx 480`);
  if (!url.includes("youtube.com") && !url.includes("youtu.be"))
    return m.reply("URL harus YouTube");

  const reso = (args[1] || "").replace(/p$/i, "");
  const resolution = RESOLUTIONS.includes(reso) ? reso : "480";

  m.react("🕕");

  const t = Date.now();
  try {
    const result = await fetchFromApi(url, resolution);

    await sock.sendMedia(m.chat, result.download, null, m, {
      type: "video",
    });
    console.log("[YTMP4 api] sukses", Date.now() - t, "ms", resolution + "p");
    m.react("✅");
  } catch (err) {
    console.error("[YTMP4]", err);
    m.react("❌");
    m.reply("Gagal mengunduh video.");
  }
}

export { pluginConfig as config, handler };