const pluginConfig = {
  name: "ytmp3",
  alias: ["youtubemp3", "ytaudio"],
  category: "download",
  description: "Download audio YouTube",
  usage: ".ytmp3 <url>",
  example: ".ytmp3 https://youtube.com/watch?v=xxx",
  cooldown: 20,
  energi: 2,
  isEnabled: true,
};

const API_URL = "https://api-cloud.my.id/downloader/youtube";
const API_TIMEOUT = 30000;

async function fetchFromApi(url) {
  const endpoint = `${API_URL}?url=${encodeURIComponent(url)}&format=mp3`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), API_TIMEOUT);

  try {
    const res = await fetch(endpoint, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`API HTTP ${res.status}`);

    const data = await res.json();
    if (!data?.status || !data?.download) {
      throw new Error(data?.error || data?.message || "API tidak mengembalikan link download");
    }

    return {
      download: data.download,
      title: data.title,
      // mp3 dari savetube, atau m4a kalau API pakai sumber clipto
      format: String(data.format || "mp3").toLowerCase(),
    };
  } finally {
    clearTimeout(timer);
  }
}

const AUDIO_MIME = {
  mp3: "audio/mpeg",
  m4a: "audio/mp4",
};

async function sendAudio(m, sock, result) {
  const mimetype = AUDIO_MIME[result.format] || "audio/mpeg";

  await sock.sendMedia(m.chat, result.download, null, m, {
    type: "audio",
    mimetype,
    ptt: false,
    fileName: `${result.title || "audio"}.${result.format}`,
  });
}

async function handler(m, { sock }) {
  const url = m.text?.trim();
  if (!url)
    return m.reply(`Contoh: ${m.prefix}ytmp3 https://youtube.com/watch?v=xxx`);
  if (!url.includes("youtube.com") && !url.includes("youtu.be"))
    return m.reply("URL harus YouTube");

  m.react("🕕");

  const t = Date.now();
  try {
    const result = await fetchFromApi(url);
    await sendAudio(m, sock, result);
    console.log("[YTMP3 api] sukses", Date.now() - t, "ms", result.format);
    m.react("✅");
  } catch (err) {
    console.error("[YTMP3]", err);
    m.react("❌");
    m.reply("Gagal mengunduh audio.");
  }
}

export { pluginConfig as config, handler };