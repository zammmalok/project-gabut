import axios from "axios";
import te from "../../src/lib/ichigo-error.js";

const config = {
  name: "play2",
  alias: ["musik2"],
  category: "downloader",
  description: "Download lagu dari YouTube via API Azbry",
  usage: ".play2 <judul lagu>",
  example: ".play2 let down radiohead",
  cooldown: 10,
  energi: 1,
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  isEnabled: true,
};

async function fetchYtPlay(query) {
  const { data } = await axios.get(
    "https://api.azbry.com/api/download/ytplay2",
    { params: { q: query }, timeout: 20000 },
  );

  if (!data?.status || !data?.result) {
    throw new Error(data?.message || "API pencarian gagal.");
  }
  return data.result;
}

async function downloadAudioBuffer(audioUrl) {
  const { data } = await axios.get(audioUrl, {
    responseType: "arraybuffer",
    timeout: 60000,
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
      Referer: "https://www.youtube.com/",
    },
  });
  return Buffer.from(data);
}

async function downloadAudioBufferWithRetry(firstResult, query) {
  let audioUrl = firstResult?.download;
  if (!audioUrl) throw new Error("Audio tidak tersedia untuk lagu ini.");

  try {
    return await downloadAudioBuffer(audioUrl);
  } catch (e) {
    console.log(`[play2] audio pertama gagal (${e.message}), mencoba ulang...`);

    const freshResult = await fetchYtPlay(query);
    audioUrl = freshResult?.download;
    if (!audioUrl) throw new Error("Audio tidak tersedia untuk lagu ini.");

    return await downloadAudioBuffer(audioUrl);
  }
}

async function handler(m, { sock }) {
  const query = (m.text || m.fullArgs || "").trim();

  if (!query) {
    return m.reply(
      `╭─ 🎵 *YOUTUBE PLAY*\n` +
      `│· Usage: \`${m.prefix}play2 <judul lagu>\`\n` +
      `│· Contoh: \`${m.prefix}play2 let down radiohead\`\n` +
      `╰───────────────────────────`,
    );
  }

  await m.react("⏳");

  try {
    const result = await fetchYtPlay(query);

    const { title, channel, thumbnail, url, download: audioUrl } = result;

    if (!audioUrl) throw new Error("Audio tidak tersedia untuk lagu ini.");

    const caption =
      `╭─ 🎵 *YOUTUBE PLAY*\n` +
      `│· Judul   : ${title}\n` +
      `│· Channel : ${channel}\n` +
      `│· Link    : ${url}\n` +
      `╰───────────────────────────\n` +
      `_⏳ Mohon tunggu ya..._`;

    await sock.sendMessage(
      m.chat,
      { image: { url: thumbnail }, caption },
      { quoted: m },
    );

    const audioBuf = await downloadAudioBufferWithRetry(result, query);

    if (audioBuf.length < 10000) throw new Error("Audio terlalu kecil / gagal diunduh.");

    const thumbBuf = await axios.get(thumbnail, {
      responseType: "arraybuffer",
      timeout: 15000,
    }).then(r => Buffer.from(r.data)).catch(() => null);

    await sock.sendMessage(
      m.chat,
      {
        audio: audioBuf,
        mimetype: "audio/mpeg",
        fileName: `${title} - ${channel}.mp3`,
        ...(thumbBuf && { jpegThumbnail: thumbBuf }),
      },
      { quoted: m },
    );

    await m.react("✅");

  } catch (e) {
    console.error("[play2]", e.message);
    await m.react("☢");
    m.reply(te(m.prefix, m.command, m.pushName));
  }
}

export { config, handler };