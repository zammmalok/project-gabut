import axios from "axios";

const pluginConfig = {
  name: "tiktok4",
  alias: ["tt4", "tiktok4", "vt4"],
  category: "downloader",
  description: "Mengunduh Video, Audio, atau Foto Slide dari TikTok via API Cloud",
  usage: ".tiktok4 <url_tiktok>",
  example: ".tiktok4 https://vt.tiktok.com/ZSbFpJ7mT/",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 5,
  energi: 1,
  isEnabled: true,
};

async function handler(m, { sock, args, prefix, command }) {
  const conn = sock || m.conn;

  // 1. Validasi Input URL
  const url = args[0] || (m.quoted && m.quoted.text);

  if (!url) {
    return m.reply(
      `❌ *URL TikTok tidak ditemukan!*\n\n` +
      `> *Penggunaan:* \`${prefix + command} <link_tiktok>\`\n` +
      `> *Contoh:* \`${prefix + command} https://vt.tiktok.com/ZSbFpJ7mT/\``
    );
  }

  if (!/tiktok\.com/i.test(url)) {
    return m.reply("❌ *URL tidak valid!* Pastikan link berasal dari TikTok.");
  }

  await m.react("⏳");

  try {
    // 2. Request ke API Cloud
    const apiUrl = `https://api-cloud.my.id/downloader/tiktok?url=${encodeURIComponent(url)}`;
    const { data: res } = await axios.get(apiUrl, { timeout: 20000 });

    if (!res) {
      await m.react("❌");
      return m.reply("⚠️ API tidak mengembalikan respon.");
    }

    // Unpack data fleksibel
    const result = res.data || res.result || res;

    // Deteksi Metadata
    const title = result.title || result.desc || result.caption || result.description || "TikTok Downloader";
    const author = result.author?.nickname || result.author?.username || result.author || result.nickname || "TikTok User";

    // 3. DETEKSI FOTO / IMAGES SLIDE
    const images = result.images || result.photo || result.slides || (Array.isArray(result.media) && typeof result.media[0] === 'string' && !result.media[0].includes('.mp4') ? result.media : null);

    if (images && Array.isArray(images) && images.length > 0) {
      await m.reply(`📸 *TikTok Photo Slide*\n\n> 👤 *Author:* ${author}\n> 📝 *Title:* ${title}\n\n_Mengirim ${images.length} foto..._`);

      for (let i = 0; i < images.length; i++) {
        const imgUrl = typeof images[i] === "string" ? images[i] : (images[i].url || images[i].display_url);
        if (imgUrl) {
          await conn.sendMessage(
            m.chat,
            {
              image: { url: imgUrl },
              caption: `🖼️ *Slide ${i + 1}/${images.length}*`,
            },
            { quoted: m }
          );
          await new Promise((res) => setTimeout(res, 500));
        }
      }

      const musicUrl = result.music || result.audio || result.music_info?.url || result.play_audio;
      if (musicUrl) {
        await conn.sendMessage(
          m.chat,
          {
            audio: { url: musicUrl },
            mimetype: "audio/mp4",
            ptt: false,
          },
          { quoted: m }
        );
      }

      await m.react("✅");
      return;
    }

    // 4. DETEKSI VIDEO (Mencakup berbagai pola property JSON)
    let videoUrl = 
      result.video || 
      result.play || 
      result.nowm || 
      result.no_watermark || 
      result.download_url || 
      result.url || 
      (typeof result.media === 'string' ? result.media : null) ||
      (Array.isArray(result.media) && result.media[0] ? (result.media[0].url || result.media[0]) : null) ||
      (result.video_data ? (result.video_data.nwm || result.video_data.wm) : null);

    if (videoUrl) {
      const captionText = 
        `🎵 *TIKTOK DOWNLOADER*\n\n` +
        `👤 *Author:* ${author}\n` +
        `📝 *Title:* ${title}\n\n` +
        `> _Powered by api-cloud.my.id_`;

      await conn.sendMessage(
        m.chat,
        {
          video: { url: videoUrl },
          caption: captionText,
        },
        { quoted: m }
      );

      await m.react("✅");
      return;
    }

    await m.react("❌");
    return m.reply("❌ Struktur respon API berubah atau media tidak ditemukan.");

  } catch (err) {
    console.error("[TikTok4 API Error]", err);
    await m.react("❌");
    return m.reply(`⚠️ *Terjadi kesalahan sistem:*\n> ${err.message || err}`);
  }
}

export { pluginConfig as config, handler };