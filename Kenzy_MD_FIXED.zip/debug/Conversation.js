=> sock.relayMessage(
  m.chat,
  {
  extendedTextMessage: {
    text: "Hai! Ada yang bisa aku bantu hari ini? Kamu bisa tanya tentang fitur, minta bantuan bikin plugin WhatsApp, atau informasi lainnya."
  }
},
  {}
)