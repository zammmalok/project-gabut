import moment from "moment-timezone";
import fs from "node:fs";
import path from "path";
import archiver from "archiver";
import config from "../../config.js";
import te from "../../src/lib/ichigo-error.js";

const pluginConfig = {
  name: "backupsc",
  alias: ["backup", "backupscript", "backupsource"],
  category: "owner",
  description: "Backup script bot dalam bentuk zip",
  usage: ".backupsc [gc/owner/chat/all]",
  example: ".backupsc | .backupsc owner | .backupsc chat | .backupsc all",
  isOwner: true,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 60,
  energi: 0,
  isEnabled: true,
};

const EXCLUDE_DIRS = new Set([
  "node_modules", ".git", "storage", "storages", "tmp", "temp",
  ".cache", "logs", "sessions", "session", "auth", ".npm", ".yarn",
  "dist", "coverage", "__pycache__", "autoreply_media", "build",
  "Baileys-master", "ichigo", "ALYA V8", "DHX-pro", "RTXZY-MD-pro",
  "BETABOTZ-MD2-pro", "KazzTzyCanvs", "starseed-main",
  "IchigoGlitch-Baileys-main", "Script Lyrra MD V7", "Sky Md V2",
  "Marin Kitagawa MD V1.0 (1)", "AmbaCrash v19 Free (1)", "@blckrose",
  "backup", "backups", "animation", "_tools", "PUSHKONTAK",
  ".vscode", ".gemini", "fischit-main",
]);

const EXCLUDE_EXTENSIONS = new Set([
  ".zip", ".tar.gz", ".7z", ".mp4", ".mp3", ".wav", ".avi", ".mkv",
  ".ico", ".svg", ".traineddata", ".log", ".bak", ".lock",
]);

const EXCLUDE_FILES = new Set([
  ".env", ".env.local", "creds.json", "package-lock.json", "yarn.lock",
  ".npmrc", ".gitignore", "boot_final.log", "bot_log.txt", "error.txt",
  "changelog.txt", "UPDATE.txt", "CHANGELOG.md",
]);

const MAX_FILE_SIZE = 50 * 1024 * 1024;
const MAX_ZIP_SIZE = 95 * 1024 * 1024;
const SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];

async function animateProgress(sock, jid, msgKey, getLabel, stopSignal) {
  let i = 0;
  while (!stopSignal.done) {
    const frame = SPINNER_FRAMES[i % SPINNER_FRAMES.length];
    const label = typeof getLabel === "function" ? getLabel() : getLabel;
    try {
      await sock.sendMessage(jid, {
        text: `${frame} ${label}`,
        edit: msgKey,
      });
    } catch {}
    i++;
    await new Promise(r => setTimeout(r, 500));
  }
}

function shouldExclude(filePath, basePath) {
  const relativePath = path.relative(basePath, filePath);
  const parts = relativePath.split(path.sep);
  for (const part of parts) {
    if (EXCLUDE_DIRS.has(part)) return true;
  }
  const fileName = path.basename(filePath);
  if (EXCLUDE_FILES.has(fileName)) return true;
  const ext = path.extname(fileName).toLowerCase();
  if (EXCLUDE_EXTENSIONS.has(ext)) {
    const isAsset =
      relativePath.startsWith("assets" + path.sep) ||
      relativePath.startsWith("database" + path.sep);
    if (!isAsset) return true;
  }
  if (fileName.endsWith(".tar.gz")) return true;
  return false;
}

function getBackupOutputDir(projectRoot) {
  const backupDir = path.join(projectRoot, "backups", "script");
  if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
  return backupDir;
}

function collectFiles(dirPath, projectRoot, fileList = []) {
  try {
    const items = fs.readdirSync(dirPath);
    for (const item of items) {
      const fullPath = path.join(dirPath, item);
      if (shouldExclude(fullPath, projectRoot)) continue;
      try {
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          collectFiles(fullPath, projectRoot, fileList);
        } else if (stat.isFile()) {
          if (stat.size > MAX_FILE_SIZE) {
            console.log(`[backupsc] Skip (terlalu besar ${(stat.size / 1024 / 1024).toFixed(1)}MB): ${path.relative(projectRoot, fullPath)}`);
            continue;
          }
          fileList.push({
            fullPath,
            relativePath: path.relative(projectRoot, fullPath),
            size: stat.size,
          });
        }
      } catch {}
    }
  } catch {}
  return fileList;
}

async function createZip(files, zipFilePath) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(zipFilePath);
    const archive = archiver("zip", { zlib: { level: 6 } });

    let settled = false;
    const fail = (error) => {
      if (settled) return;
      settled = true;
      try { output.destroy(); } catch {}
      try { if (fs.existsSync(zipFilePath)) fs.unlinkSync(zipFilePath); } catch {}
      reject(error);
    };

    output.on("error", fail);
    output.on("close", () => {
      if (settled) return;
      settled = true;
      if (!fs.existsSync(zipFilePath)) {
        fail(new Error("File backup tidak ditemukan setelah proses zip"));
        return;
      }
      const stats = fs.statSync(zipFilePath);
      if (stats.size <= 0) {
        fail(new Error("File backup kosong atau 0KB"));
        return;
      }
      resolve(stats.size);
    });

    archive.on("error", fail);
    archive.on("warning", (err) => { if (err?.code !== "ENOENT") fail(err); });
    archive.pipe(output);

    for (const file of files) {
      archive.file(file.fullPath, { name: file.relativePath });
    }

    if (files.length === 0) {
      fail(new Error("Tidak ada file yang masuk ke backup script"));
      return;
    }

    archive.finalize();
  });
}

async function sendZipTo(sock, jid, zipFilePath, zipFileName, caption) {
  await sock.sendMessage(jid, {
    document: fs.readFileSync(zipFilePath),
    fileName: zipFileName,
    mimetype: "application/zip",
    caption,
    contextInfo: {
      forwardingScore: 9999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: config.saluran?.id || "120363400911374213@newsletter",
        newsletterName: config.saluran?.name || config.bot?.name || "Ichigo-AI",
        serverMessageId: 127,
      },
    },
  });
}

function getOwnerJids() {
  const raw = config.owner;
  let numbers = [];
  if (Array.isArray(raw)) numbers = raw;
  else if (Array.isArray(raw?.number)) numbers = raw.number;
  else if (typeof raw?.number === "string") numbers = [raw.number];
  else if (typeof raw === "string") numbers = [raw];
  return numbers
    .map((n) => `${String(n).replace(/[^0-9]/g, "")}@s.whatsapp.net`)
    .filter(Boolean);
}

function getConfiguredGcJid() {
  const raw = (config.idgc || "").trim();
  if (!raw) return "";
  return raw.includes("@") ? raw : `${raw}@g.us`;
}

function resolveTargets(arg, ownerJids, chatJid, gcJid) {
  const a = (arg || "").trim().toLowerCase();

  if (a === "owner") {
    return { targets: [...ownerJids] };
  }
  if (a === "gc") {
    if (!gcJid) return { targets: [] };
    return { targets: [gcJid] };
  }
  if (a === "chat") {
    return { targets: [chatJid] };
  }
  if (a === "all") {
    const targets = [...ownerJids];
    if (gcJid && !targets.includes(gcJid)) targets.push(gcJid);
    if (!targets.includes(chatJid)) targets.push(chatJid);
    return { targets };
  }

  // Default (tanpa argumen): langsung ke GC yang udah di-set di config.js (idgc).
  // Kalau idgc belum di-set, fallback ke chat tempat command ini dipanggil.
  if (gcJid) {
    return { targets: [gcJid] };
  }
  return { targets: [chatJid] };
}

function describeTargets(targets, ownerJids, chatJid, gcJid) {
  const toOwner = targets.some(t => ownerJids.includes(t));
  const toGc = gcJid && targets.includes(gcJid);
  const toChat = targets.includes(chatJid) && chatJid !== gcJid;

  const parts = [];
  if (toOwner) parts.push(`${ownerJids.length} owner`);
  if (toGc) parts.push(toGc && chatJid === gcJid ? "GC ini (idgc)" : "GC (idgc)");
  if (toChat) parts.push("GC ini");

  return parts.length ? parts.join(" + ") : "target yang dipilih";
}

async function handler(m, { sock }) {
  await m.react("🕕");

  const initMsg = await sock.sendMessage(m.chat, {
    text: `⠋ Memulai backup script...`,
  }, { quoted: m });
  const animKey = initMsg?.key;

  const stopSignal = { done: false };
  let animLabel = "Memulai backup script...";

  const stop = async () => {
    stopSignal.done = true;
    await animLoop;
  };

  const animLoop = animKey
    ? animateProgress(sock, m.chat, animKey, () => animLabel, stopSignal)
    : Promise.resolve();

  try {
    const projectRoot = process.cwd();
    const timestamp = moment().tz("Asia/Makassar").format("YYYY-MM-DD_HH-mm-ss");
    const botName = config.bot?.name?.replace(/[^a-zA-Z0-9]/g, "") || "IchigoBot";
    const backupDir = getBackupOutputDir(projectRoot);
    const ownerJids = getOwnerJids();
    const gcJid = getConfiguredGcJid();

    const arg = m.text?.trim().toLowerCase() || "";
    const { targets } = resolveTargets(arg, ownerJids, m.chat, gcJid);

    const needsOwner = arg === "owner" || arg === "all";
    if (needsOwner && ownerJids.length === 0) {
      await stop();
      await m.react("❌");
      return m.reply(`❌ Tidak ada nomor owner di config.js!`);
    }

    if (arg === "gc" && !gcJid) {
      await stop();
      await m.react("❌");
      return m.reply(`❌ \`idgc\` belum di-set di config.js!`);
    }

    if (targets.length === 0) {
      await stop();
      await m.react("❌");
      if (arg === "" ) {
        return m.reply(
          `❌ \`idgc\` belum di-set di config.js dan gagal fallback ke chat ini.`
        );
      }
      return m.reply(`❌ Tidak ada target penerima backup!`);
    }

    const targetDesc = describeTargets(targets, ownerJids, m.chat, gcJid);

    animLabel = "Mengumpulkan file...";
    const allFiles = collectFiles(projectRoot, projectRoot);

    if (allFiles.length === 0) {
      await stop();
      await m.react("❌");
      return m.reply(`❌ Tidak ada file yang bisa di-backup!`);
    }

    const totalSize = allFiles.reduce((acc, f) => acc + f.size, 0);
    const totalSizeMB = (totalSize / 1024 / 1024).toFixed(2);
    const needSplit = totalSize > MAX_ZIP_SIZE;

    if (!needSplit) {
      const zipFileName = `${botName}_backup_${timestamp}.zip`;
      const zipFilePath = path.join(backupDir, zipFileName);

      animLabel = `Mengkompresi ${allFiles.length} file (~${totalSizeMB} MB)...`;
      const zipSize = await createZip(allFiles, zipFilePath);
      const zipSizeMB = (zipSize / 1024 / 1024).toFixed(2);

      animLabel = `Mengirim ke ${targetDesc}...`;

      const caption =
        `✅ *ʙᴀᴄᴋᴜᴘ sᴇʟᴇsᴀɪ*\n\n` +
        `╭┈┈⬡「 📋 *ᴅᴇᴛᴀɪʟ* 」\n` +
        `┃ 📝 ɴᴀᴍᴀ: \`${zipFileName}\`\n` +
        `┃ 📊 sɪᴢᴇ: \`${zipSizeMB} MB\`\n` +
        `┃ 📁 ꜰɪʟᴇ: \`${allFiles.length}\`\n` +
        `┃ 📅 ᴛᴀɴɢɢᴀʟ: \`${moment().tz("Asia/Makassar").format("DD/MM/YYYY HH:mm")}\`\n` +
        `╰┈┈⬡`;

      for (const jid of targets) {
        try {
          await sendZipTo(sock, jid, zipFilePath, zipFileName, caption);
        } catch (e) {
          console.error(`[backupsc] Gagal kirim ke ${jid}:`, e.message);
        }
      }

      try { fs.unlinkSync(zipFilePath); } catch {}

      await stop();
      await m.react("✅");
      await m.reply(`✅ Backup berhasil dikirim ke *${targetDesc}*!`);

    } else {
      
      const parts = [];
      let chunkFiles = [];
      let chunkSizeAccum = 0;

      for (const file of allFiles) {
        if (chunkSizeAccum + file.size > MAX_ZIP_SIZE && chunkFiles.length > 0) {
          parts.push([...chunkFiles]);
          chunkFiles = [];
          chunkSizeAccum = 0;
        }
        chunkFiles.push(file);
        chunkSizeAccum += file.size;
      }
      if (chunkFiles.length > 0) parts.push(chunkFiles);

      for (let i = 0; i < parts.length; i++) {
        const zipFileName = `${botName}_backup_${timestamp}_part${i + 1}of${parts.length}.zip`;
        const zipFilePath = path.join(backupDir, zipFileName);

        animLabel = `Mengkompresi part ${i + 1}/${parts.length} (${parts[i].length} file)...`;
        const zipSize = await createZip(parts[i], zipFilePath);
        const zipSizeMB = (zipSize / 1024 / 1024).toFixed(2);

        animLabel = `Mengirim part ${i + 1}/${parts.length} ke ${targetDesc}...`;

        const caption =
          `✅ *ʙᴀᴄᴋᴜᴘ ᴘᴀʀᴛ ${i + 1}/${parts.length}*\n\n` +
          `╭┈┈⬡「 📋 *ᴅᴇᴛᴀɪʟ* 」\n` +
          `┃ 📝 ɴᴀᴍᴀ: \`${zipFileName}\`\n` +
          `┃ 📊 sɪᴢᴇ: \`${zipSizeMB} MB\`\n` +
          `┃ 📁 ꜰɪʟᴇ: \`${parts[i].length}\`\n` +
          `┃ 📅 ᴛᴀɴɢɢᴀʟ: \`${moment().tz("Asia/Makassar").format("DD/MM/YYYY HH:mm")}\`\n` +
          `╰┈┈⬡`;

        for (const jid of targets) {
          try {
            await sendZipTo(sock, jid, zipFilePath, zipFileName, caption);
          } catch (e) {
            console.error(`[backupsc] Gagal kirim ke ${jid}:`, e.message);
          }
        }

        try { fs.unlinkSync(zipFilePath); } catch {}
      }

      await stop();
      await m.react("✅");
      await m.reply(`✅ Semua *${parts.length} bagian* berhasil dikirim ke *${targetDesc}*!`);
    }

  } catch (error) {
    await stop();
    console.error("[backupsc] Error:", error);
    await m.react("☢");
    await m.reply(te(m.prefix, m.command, m.pushName));
  }
}

export { pluginConfig as config, handler };