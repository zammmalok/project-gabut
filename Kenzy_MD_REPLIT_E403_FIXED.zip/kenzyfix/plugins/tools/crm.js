import fs from 'node:fs';
import path from 'path';
import os from 'os';
import crypto from 'crypto';
import { proto } from 'ichigo';

let AIRich = null;
try {
  const mb = await import('../../src/lib/ichigo-builder.js');
  AIRich = mb.AIRich || null;
} catch {}

const pluginConfig = {
  name: "crm",
  alias: ["rawmsg", "crm2", "insp", "adn", "relay"],
  category: "tools",
  description: "Raw Message & Deep Inspector - dump payload, ekstrak quoted, generate relay snippet, dan re-relay pesan",
  usage: ".crm (reply pesan)\n.crm -snip\n.crm -meta\n.crm -quoted\n.crm -full\n.crm -relay\n.crm -option\n.crm -message\n.crm -info\n.crm -key\n.crm -ctx\n.crm -types\n.crm -run\n.crm2\n.insp\n.adn\n.relay [jid] [-samekey]",
  example: ".crm -info",
  isOwner: true,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 5,
  energi: 1,
  isEnabled: true,
};

const MIME_MAP = {
  json: 'application/json',
  js: 'application/javascript',
  txt: 'text/plain'
};

const PROTO_ENUM_MAP = {
  NONE: 0,
  VIDEO: 4,
  IMAGE: 4,
  VIDEO_STATUS: 5,
  ALL: 0,
  CLOSE_FRIENDS: 2,
  SANS_SERIF: 0,
  SERIF: 1,
  NORICAN_REGULAR: 2,
  BRYNDAN_WRITE: 3,
  BEBASNEUE_REGULAR: 4,
  OSWALD_HEAVY: 5,
  DEFAULT: 0,
  PARENT: 1,
  CHANGED_IN_CHAT: 0,
  LID: 1,
};

const WRAPPER_KEYS_FALLBACK = [
  'ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension',
  'documentWithCaptionMessage', 'editedMessage', 'ptvMessage', 'deviceSentMessage',
  'lottieStickerMessage', 'associatedChildMessage', 'keepInChatMessage', 'pinInChatMessage',
  'botForwardedMessage',
];

function resolveField(field) {
  try {
    field.resolve?.();
  } catch {}
  return field?.resolvedType || null;
}

function getMessageTypeDescriptor() {
  const t = proto?.Message?.$type;
  if (t?.fieldsArray) return t;
  if (proto?.Message?.fieldsArray) return proto.Message;
  return null;
}

function getAllBaileysMessageTypes() {
  const desc = getMessageTypeDescriptor();
  return desc ? desc.fieldsArray.map(f => f.name) : [];
}

function discoverWrapperKeys() {
  const desc = getMessageTypeDescriptor();
  if (!desc) return WRAPPER_KEYS_FALLBACK;
  const found = [];
  for (const field of desc.fieldsArray) {
    const resolved = resolveField(field);
    if (!resolved) continue;
    if (resolved.name === 'Message') {
      found.push(field.name);
      continue;
    }
    const hasNestedMessage = (resolved.fieldsArray || []).some(sf => sf.name === 'message' && resolveField(sf)?.name === 'Message');
    if (hasNestedMessage) found.push(field.name);
  }
  return Array.from(new Set([...found, ...WRAPPER_KEYS_FALLBACK]));
}

const WRAPPER_KEYS = discoverWrapperKeys();

const HELP = `⚠️ *Reply pesan dulu!*

*.crm* 
› *.crm*
› *.crm -snip*
› *.crm -meta*
› *.crm -quoted*
› *.crm -full*
› *.crm -relay*
› *.crm -option*
› *.crm -message*
› *.crm -info*
› *.crm -key*
› *.crm -ctx*
› *.crm -types*
› *.crm -run* (file snippet + payload utuh, siap di-*.run*)
› tambahkan *-file* 

*.crm2*  
*.insp*
*.adn* 
*.relay [jid] [-samekey]*`;

function fixEnums(obj) {
  if (Array.isArray(obj)) return obj.map(fixEnums);
  if (obj && typeof obj === 'object') {
    if (obj.type === 'Buffer' && Array.isArray(obj.data)) return obj;
    return Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, fixEnums(v)]));
  }
  if (typeof obj === 'string' && obj in PROTO_ENUM_MAP) return PROTO_ENUM_MAP[obj];
  return obj;
}

function prepareForRelay(obj) {
  if (Array.isArray(obj)) return obj.map(prepareForRelay);
  if (obj && typeof obj === 'object') {
    if (obj.type === 'Buffer' && Array.isArray(obj.data)) return obj;
    const res = {};
    for (const [k, v] of Object.entries(obj)) {
      if (k.endsWith('Json') || k === 'data') {
        if (typeof v === 'object' && v !== null) {
          res[k] = JSON.stringify(prepareForRelay(v));
        } else if (typeof v === 'string') {
          res[k] = v;
        } else {
          res[k] = String(v ?? '');
        }
      } else {
        res[k] = prepareForRelay(v);
      }
    }
    return res;
  }
  return obj;
}

const SPECIAL_TYPES = [{
    match: /^eventMessage$/,
    secret: true,
    nodes: [{
      tag: 'meta',
      attrs: {
        event_type: 'creation'
      }
    }]
  },
  {
    match: /^pollCreationMessage/,
    secret: true,
    nodes: [{
      tag: 'meta',
      attrs: {
        polltype: 'creation'
      }
    }]
  },
];

function getSpecialType(type) {
  return SPECIAL_TYPES.find(s => s.match.test(type)) || null;
}

function normalizePayloadForRelay(rawMsg) {
  let fixed = prepareForRelay(fixEnums(rawMsg));
  const type = getMsgType(fixed);
  const special = getSpecialType(type);

  if (fixed?.interactiveMessage?.nativeFlowMessage) {
    if (!fixed.interactiveMessage.nativeFlowMessage.messageParamsJson || fixed.interactiveMessage.nativeFlowMessage.messageParamsJson === '{}') {
      fixed.interactiveMessage.nativeFlowMessage.messageParamsJson = JSON.stringify({
        v: '1'
      });
    }
  }

  if (special?.secret && !fixed.messageContextInfo?.messageSecret) {
    fixed = {
      ...fixed,
      messageContextInfo: {
        ...(fixed.messageContextInfo || {}),
        messageSecret: crypto.randomBytes(32).toString('base64')
      }
    };
  }

  if (type === 'richResponseMessage') {
    fixed = { botForwardedMessage: { message: fixed } };
  } else if (isInteractiveType(type, fixed)) {
    fixed = {
      viewOnceMessage: {
        message: fixed
      }
    };
  }

  return fixed;
}

function parseAsJsonObjectOrArray(str) {
  if (typeof str !== 'string' || !str.trim()) return null;
  const trimmed = str.trim();
  if (!(trimmed.startsWith('{') || trimmed.startsWith('['))) return null;
  try {
    const parsed = JSON.parse(trimmed);
    if (parsed !== null && typeof parsed === 'object') return parsed;
  } catch {}
  return null;
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function isJwt(str) {
  return typeof str === 'string' && /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(str);
}

function decodeJwt(str) {
  try {
    const [h, p] = str.split('.');
    const dec = s => JSON.parse(Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'));
    return {
      header: dec(h),
      payload: dec(p)
    };
  } catch {
    return null;
  }
}

function looksLikeBase64(str) {
  if (typeof str !== 'string') return false;
  const s = str.trim();
  if (s.length < 8 || s.length % 4 !== 0) return false;
  return /^[A-Za-z0-9+/]+={0,2}$/.test(s);
}

function tryBase64Json(str) {
  if (!looksLikeBase64(str)) return null;
  try {
    const decoded = Buffer.from(str, 'base64').toString('utf8');
    const parsed = JSON.parse(decoded);
    if (parsed !== null && typeof parsed === 'object') return parsed;
  } catch {}
  return null;
}

function deepDecode(obj, stats = { count: 0 }) {
  if (Array.isArray(obj)) return obj.map(v => deepDecode(v, stats));
  if (obj && typeof obj === 'object') {
    if (obj.type === 'Buffer' && Array.isArray(obj.data)) return obj;
    return Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, deepDecode(v, stats)]));
  }
  if (typeof obj === 'string') {
    const asJson = parseAsJsonObjectOrArray(obj);
    if (asJson !== null) {
      stats.count++;
      return deepDecode(asJson, stats);
    }
    if (isJwt(obj)) {
      const decoded = decodeJwt(obj);
      if (decoded) {
        stats.count++;
        return {
          _jwt: obj,
          _decoded: decoded
        };
      }
    }
    const asB64 = tryBase64Json(obj);
    if (asB64 !== null) {
      stats.count++;
      return deepDecode(asB64, stats);
    }
  }
  return obj;
}

function decodeEmbeddedValue(str) {
  const asJson = parseAsJsonObjectOrArray(str);
  if (asJson !== null) return {
    kind: 'json',
    value: asJson
  };
  const asB64 = tryBase64Json(str);
  if (asB64 !== null) return {
    kind: 'base64',
    value: asB64
  };
  return null;
}

function safeJson(obj, indent = 2, depth = 0, currentKey = '', execMode = false) {
  const pad = ' '.repeat(indent * (depth + 1));
  const closePad = ' '.repeat(indent * depth);

  if (obj === null) return 'null';
  if (obj === undefined) return 'undefined';
  if (obj?.type === 'Buffer' && Array.isArray(obj.data)) return `"<Buffer ${obj.data.length} bytes>"`;

  if (Array.isArray(obj)) {
    if (!obj.length) return '[]';
    const items = obj.map(v => pad + safeJson(v, indent, depth + 1, currentKey, execMode));
    return `[\n${items.join(',\n')}\n${closePad}]`;
  }

  if (typeof obj === 'object') {
    const keys = Object.keys(obj);
    if (!keys.length) return '{}';
    const entries = keys.map(k => `${pad}${JSON.stringify(k)}: ${safeJson(obj[k], indent, depth + 1, k, execMode)}`);
    return `{\n${entries.join(',\n')}\n${closePad}}`;
  }

  if (typeof obj === 'string') {
    const mustStayString = currentKey.endsWith('Json') || currentKey === 'data';
    if (mustStayString) {
      if (execMode) {
        const decoded = decodeEmbeddedValue(obj);
        if (decoded) {
          const inner = safeJson(decoded.value, indent, depth, currentKey, execMode);
          return currentKey === 'data' ?
            `Buffer.from(JSON.stringify(${inner}), 'utf8').toString('base64')` :
            `JSON.stringify(${inner})`;
        }
      }
      return JSON.stringify(obj);
    }
    const asJsonObj = parseAsJsonObjectOrArray(obj);
    if (asJsonObj !== null) return safeJson(asJsonObj, indent, depth, currentKey, execMode);
    return JSON.stringify(obj);
  }

  return JSON.stringify(obj);
}

/**
 * Serialize payload tanpa kehilangan data biner supaya bisa di-restore `.run`.
 * Buffer / Uint8Array → { __buf: base64 }, BigInt → { __big: "123" }.
 * (Buffer di rawMsg biasanya sudah berbentuk { type: 'Buffer', data: [...] } hasil JSON.)
 */
function serializePayloadExact(obj) {
  return JSON.stringify(obj, (k, v) => {
    if (typeof v === 'bigint') return { __big: v.toString() };
    if (v && v.type === 'Buffer' && Array.isArray(v.data)) return { __buf: Buffer.from(v.data).toString('base64') };
    if (v instanceof Uint8Array) return { __buf: Buffer.from(v).toString('base64') };
    return v;
  }, 2);
}

/**
 * Blok komentar berisi payload utuh (dibaca `.run` lewat penanda RELAY_PAYLOAD_START/END).
 * Penutup komentar (bintang + garis miring) di dalam string di-escape jadi `*\/` (tetap JSON valid)
 * supaya blok komentar di file nggak ketutup lebih awal.
 */
function buildPayloadBlock(content, options = {}) {
  const json = serializePayloadExact({ chat: '-', content, options }).replace(/\*\//g, '*\\/');
  return `/*\nRELAY_PAYLOAD_START\n${json}\nRELAY_PAYLOAD_END\n*/`;
}

function getMsgType(msg) {
  return Object.keys(msg || {}).find(k => !['messageContextInfo', 'senderKeyDistributionMessage'].includes(k)) || 'unknownMessage';
}

const KNOWN_NATIVE_FLOW_TYPES = ['buttonsMessage', 'listMessage', 'templateMessage', 'interactiveMessage'];

function isInteractiveType(type, payload) {
  const body = payload?.[type];
  if (body && typeof body === 'object') {
    if ('nativeFlowMessage' in body) return true;
    if ('hydratedTemplate' in body) return true;
    if ('templateButtons' in body && Array.isArray(body.templateButtons) && body.templateButtons.length) return true;
    if ('buttons' in body && Array.isArray(body.buttons) && body.buttons.length) return true;
    if (type === 'listMessage' && 'sections' in body) return true;
  }
  return KNOWN_NATIVE_FLOW_TYPES.includes(type);
}

function listAllBaileysMessageTypes() {
  const types = getAllBaileysMessageTypes();
  const wrappers = new Set(WRAPPER_KEYS);
  return types.map(t => `${wrappers.has(t) ? '📦' : '•'} ${t}`).join('\n') || '(gagal baca proto.Message)';
}

function shortStr(str, n = 28) {
  str = String(str ?? '-');
  return str.length > n ? str.slice(0, 12) + '...' + str.slice(-8) : str;
}

function getSize(obj) {
  try {
    const b = Buffer.byteLength(JSON.stringify(obj), 'utf8');
    return b < 1024 ? `${b} B` : `${(b / 1024).toFixed(1)} KB`;
  } catch {
    return '-';
  }
}

function countKeys(obj, depth = 0) {
  if (depth > 5 || typeof obj !== 'object' || !obj) return 0;
  return Object.values(obj).reduce((n, v) => n + 1 + (typeof v === 'object' && v ? countKeys(v, depth + 1) : 0), 0);
}

function getTimestamp(quoted, rawMsg, msgType) {
  const candidates = [
    quoted?.messageTimestamp, quoted?.t, quoted?.timestamp,
    quoted?.vM?.messageTimestamp, quoted?.vM?.t, quoted?.vM?.key?.messageTimestamp,
    quoted?.msg?.messageTimestamp, rawMsg?.[msgType]?.contextInfo?.timestamp,
  ];
  for (const c of candidates) {
    if (c === undefined || c === null) continue;
    const num = Number(c);
    if (Number.isFinite(num) && num > 0) return num;
  }
  return null;
}

function decodeProto(rawObj) {
  if (!rawObj) return null;
  try {
    return proto.WebMessageInfo.toObject(
      proto.WebMessageInfo.fromObject(rawObj), {
        enums: Number,
        longs: Number,
        bytes: String,
        defaults: false
      }
    );
  } catch {
    return null;
  }
}

function unwrapMessage(msg, preserveContext = true) {
  let current = msg;
  const chain = [];
  let guard = 0;
  let savedContext = null;

  while (current && typeof current === 'object' && guard < 10) {
    guard++;
    const keys = Object.keys(current);

    const typeKey = getMsgType(current);
    if (current[typeKey]?.contextInfo) {
      savedContext = current[typeKey].contextInfo;
    }

    const wrapperKey = keys.find(k => WRAPPER_KEYS.includes(k));
    if (!wrapperKey) break;
    const inner = current[wrapperKey]?.message;
    if (!inner) break;
    chain.push(wrapperKey);
    current = inner;
  }

  if (preserveContext && savedContext) {
    const finalType = getMsgType(current);
    if (current[finalType] && typeof current[finalType] === 'object' && !current[finalType].contextInfo) {
      current[finalType].contextInfo = savedContext;
    }
  }

  return {
    msg: current || msg,
    chain
  };
}

function extractDeepQuoted(quoted) {
  if (!quoted) return null;

  const ctxQuoted = quoted.message?.[getMsgType(quoted.message)]?.contextInfo?.quotedMessage ||
    quoted.vM?.message?.[getMsgType(quoted.vM?.message)]?.contextInfo?.quotedMessage;

  if (ctxQuoted) {
    return unwrapMessage(ctxQuoted).msg;
  }

  if (quoted.quoted?.message) {
    return unwrapMessage(quoted.quoted.message).msg;
  }

  return null;
}

async function tryStoreLoadMessage(quoted) {
  try {
    const store = global.store;
    if (!store?.loadMessage) return null;
    const msg = await store.loadMessage(quoted.chat, quoted.id);
    if (!msg) return null;
    return msg;
  } catch {
    return null;
  }
}

function getMsgSource(sock, quoted, options = {}) {
  const attempts = [
    () => {
      const stored = sock.loadMessage?.(quoted.id);
      return stored ? {
        type: 'store',
        raw: stored
      } : null;
    },
    () => (quoted.vM ? {
      type: 'vM',
      raw: quoted.vM
    } : null),
    () => {
      const cached = sock.chats?.[quoted.chat || '']?.messages?.[quoted.id];
      return cached ? {
        type: 'sock.chats cache',
        raw: cached
      } : null;
    },
    () => {
      const msg = quoted.fakeObj?.message || quoted.message;
      return msg ? {
        type: 'quoted.message (fallback)',
        raw: {
          key: quoted.vM?.key,
          message: msg
        }
      } : null;
    },
  ];

  for (const attempt of attempts) {
    const result = attempt();
    if (!result) continue;

    if (result.type === 'quoted.message (fallback)') {
      const {
        msg: unwrapped,
        chain
      } = unwrapMessage(result.raw.message, !options.full);
      return {
        type: result.type,
        msg: unwrapped,
        chain,
        fullRaw: result.raw
      };
    }

    const decoded = decodeProto(result.raw);
    if (decoded?.message) {
      const rawMsgStr = JSON.stringify(decoded.message);
      if (rawMsgStr.includes('richResponseMessage')) {
        let fixedMsg = decoded.message;
        if (!fixedMsg.richResponseMessage && fixedMsg.botForwardedMessage?.message?.richResponseMessage) {
          fixedMsg = fixedMsg.botForwardedMessage.message;
        }
        return {
          type: result.type,
          msg: fixedMsg.richResponseMessage ? fixedMsg : { richResponseMessage: fixedMsg.richResponseMessage || {} },
          chain: ['richResponseMessage_forced'],
          fullRaw: decoded
        };
      }

      const {
        msg: unwrapped,
        chain
      } = unwrapMessage(decoded.message, !options.full);
      return {
        type: result.type,
        msg: unwrapped,
        chain,
        fullRaw: decoded
      };
    }
  }

  const fallbackMsg = quoted.message || quoted.vM?.message;
  if (fallbackMsg) {
    const { msg: unwrapped, chain } = unwrapMessage(fallbackMsg, !options.full);
    return {
      type: 'fallback.raw',
      msg: unwrapped,
      chain,
      fullRaw: quoted
    };
  }

  return {
    type: null,
    msg: null,
    chain: [],
    fullRaw: null
  };
}

async function getRawMsg(sock, quoted, options = {}) {
  if (options.viaStore) {
    const stored = await tryStoreLoadMessage(quoted);
    if (!stored) return {
      msg: null,
      source: 'store.loadMessage',
      chain: [],
      fullRaw: null
    };
    return {
      msg: stored,
      source: 'store.loadMessage',
      chain: [],
      fullRaw: stored,
      isFullDump: true
    };
  }

  const {
    type,
    msg,
    chain,
    fullRaw
  } = getMsgSource(sock, quoted, options);
  if (!msg) return {
    msg: null,
    source: type,
    chain: [],
    fullRaw: null
  };
  return {
    msg,
    source: type,
    chain,
    fullRaw
  };
}

function getRawMsgFromCache(sock, chat, id) {
  const cached = sock.chats?.[chat]?.messages?.[id];
  if (!cached) return {
    msg: null,
    source: null,
    chain: []
  };
  const decoded = decodeProto(cached);
  if (!decoded?.message) return {
    msg: null,
    source: 'sock.chats cache',
    chain: []
  };
  const {
    msg: unwrapped,
    chain
  } = unwrapMessage(decoded.message);
  return {
    msg: unwrapped,
    source: 'sock.chats cache',
    chain
  };
}

function getQuotedKey(sock, quoted, chat, sender, id) {
  if (quoted.vM?.key) return quoted.vM.key;
  const stored = sock.loadMessage?.(id);
  if (stored?.key) return stored.key;
  return {
    remoteJid: chat,
    fromMe: !!quoted.fromMe,
    id,
    ...(chat?.endsWith('@g.us') ? {
      participant: sender
    } : {})
  };
}

function findAdditionalNodesDeep(obj, depth = 0, maxDepth = 6) {
  if (depth > maxDepth || !obj || typeof obj !== 'object') return null;
  if (Array.isArray(obj)) {
    for (const item of obj) {
      const found = findAdditionalNodesDeep(item, depth + 1, maxDepth);
      if (found) return found;
    }
    return null;
  }
  if ('additionalNodes' in obj) {
    const val = obj.additionalNodes;
    if (val && (Array.isArray(val) ? val.length : Object.keys(val).length)) return val;
  }
  for (const v of Object.values(obj)) {
    if (v && typeof v === 'object') {
      const found = findAdditionalNodesDeep(v, depth + 1, maxDepth);
      if (found) return found;
    }
  }
  return null;
}

function getAdditionalNodes(quoted, rawMsg, msgType) {
  const ctx = (rawMsg?.[msgType] || {}).contextInfo || {};
  const shallow = [quoted?.additionalNodes, quoted?.vM?.additionalNodes, ctx?.additionalNodes, rawMsg?.additionalNodes];
  for (const c of shallow) {
    if (c && (Array.isArray(c) ? c.length : Object.keys(c).length)) return {
      nodes: c,
      synthetic: false
    };
  }

  const deep = findAdditionalNodesDeep(quoted?.vM) || findAdditionalNodesDeep(rawMsg);
  if (deep) return {
    nodes: deep,
    synthetic: false
  };

  const special = getSpecialType(msgType);
  if (special) return {
    nodes: special.nodes,
    synthetic: true
  };

  if (isInteractiveType(msgType, rawMsg)) {
    return {
      nodes: [{
        tag: 'biz',
        attrs: {},
        content: [{
          tag: 'interactive',
          attrs: {
            type: 'native_flow',
            v: '1'
          },
          content: [{
            tag: 'native_flow',
            attrs: {
              v: '9',
              name: 'mixed'
            }
          }]
        }]
      }],
      synthetic: true
    };
  }

  return {
    nodes: null,
    synthetic: false
  };
}

function buildFileName(tag, ext, msgType) {
  const safeType = String(msgType || 'unknownMessage').replace(/[^a-zA-Z0-9]/g, '') || 'unknownMessage';
  if (!tag || tag === 'raw') return `${safeType}.${ext}`;
  return `${safeType}-${tag}.${ext}`;
}

async function sendAsFile(sock, m, content, tag, ext, caption, msgType) {
  const filename = buildFileName(tag, ext, msgType);
  const filePath = path.join(os.tmpdir(), filename);
  const mimetype = MIME_MAP[ext] || 'application/octet-stream';
  fs.writeFileSync(filePath, content, 'utf8');
  try {
    await sock.sendMessage(m.chat, {
      document: fs.readFileSync(filePath),
      mimetype,
      fileName: filename,
      caption
    }, {
      quoted: m
    });
  } finally {
    fs.unlink(filePath, () => {});
  }
}

async function sendAsCode(sock, m, {
  heading,
  meta,
  pills = [],
  code,
  language = 'json'
}) {
  if (AIRich) {
    try {
      const rich = new AIRich(sock);
      if (heading) rich.addText(heading);
      if (meta) rich.addMetadata(meta);
      const cleanPills = pills.filter(Boolean).map(String);
      if (cleanPills.length) rich.addSuggest(cleanPills);
      rich.addCode(language, code);
      return await rich.send(m.chat, {
        quoted: m
      });
    } catch {}
  }
  const text = `${heading ? heading + '\n\n' : ''}${meta ? meta + '\n\n' : ''}\`\`\`${language}\n${code}\n\`\`\``;
  return sock.sendMessage(m.chat, {
    text
  }, {
    quoted: m
  });
}

async function sendAuto(sock, m, {
  heading,
  meta,
  pills,
  code,
  language,
  fileTag,
  fileExt,
  fileCaption,
  msgType,
  forceFile = false,
  fileTrailer = ''
}) {
  if (forceFile || code.length > 5000) {
    const fileBody = heading ?
      `${heading.replace(/^#+\s*/, '// ')}\n${meta ? meta.split('\n').map(l => '// ' + l).join('\n') + '\n\n' : ''}${code}` :
      code;
    return sendAsFile(sock, m, fileTrailer ? `${fileBody}\n\n${fileTrailer}` : fileBody, fileTag, fileExt, fileCaption, msgType);
  }
  return sendAsCode(sock, m, {
    heading,
    meta,
    pills,
    code,
    language
  });
}

async function react(sock, m, emoji) {
  return sock.sendMessage(m.chat, {
    react: {
      text: emoji,
      key: m.reactKey || m.key
    }
  });
}

async function runCrm(m, {
  sock,
  args
}, {
  fromCache = false
} = {}) {
  const preFlag = args.join(' ').toLowerCase().trim();

  if (preFlag.includes('-types')) {
    const list = listAllBaileysMessageTypes();
    const meta = `📦 = terdeteksi sebagai wrapper (auto dari refleksi proto.Message)\n• = tipe konten biasa`;
    return sendAuto(sock, m, {
      heading: '# 🧩 Semua Tipe Message (proto.Message — ichigo)',
      meta,
      pills: [],
      code: list,
      language: 'text',
      fileTag: 'types',
      fileExt: 'txt',
      fileCaption: `🧩 *Semua Tipe Message dari ichigo*\n\n${meta}`,
      msgType: 'reference',
      forceFile: list.split('\n').length > 40,
    });
  }

  if (!m.quoted) return m.reply(HELP);
  await react(sock, m, '⏳');

  try {
    const quoted = m.quoted;
    const chat = quoted.chat || m.chat || '-';
    const id = quoted.id || '-';
    const flag = args.join(' ').toLowerCase().trim();
    const isFull = flag.includes('-full');
    const isGetQuoted = flag.includes('-quoted');
    const isStore = flag.includes('-store');

    if (isStore) {
      const {
        msg: storeMsg,
        source
      } = await getRawMsg(sock, quoted, {
        viaStore: true
      });
      if (!storeMsg) {
        await react(sock, m, '❌');
        return m.reply('❌ Tidak ketemu di store.loadMessage(chat, id).');
      }
      const forceFile = flag.includes('-file');
      const dump = JSON.stringify(storeMsg, null, 2);
      await sendAuto(sock, m, {
        heading: '# 🗄️ store.loadMessage Dump',
        meta: `• Source  : ${source}\n• Chat    : ${shortStr(chat)}\n• ID      : ${id}`,
        pills: ['store', chat, id],
        code: dump,
        language: 'json',
        fileTag: 'store',
        fileExt: 'json',
        fileCaption: `🗄️ *store.loadMessage Dump*\n\nChat: ${shortStr(chat)}\nID: ${id}`,
        msgType: 'store',
        forceFile
      });
      return react(sock, m, '✅');
    }

    let {
      msg: rawMsg,
      source,
      chain
    } = fromCache
      ?
      getRawMsgFromCache(sock, chat, id) :
      await getRawMsg(sock, quoted, {
        full: isFull
      });

    if (isGetQuoted) {
      const deepQuoted = extractDeepQuoted(quoted);
      if (deepQuoted) {
        rawMsg = deepQuoted;
        source = 'contextInfo.quotedMessage (deep extracted)';
      } else {
        await react(sock, m, '❌');
        return m.reply('❌ Pesan ini tidak mereply/mengutip pesan lain (quotedMessage tidak ditemukan).');
      }
    }

    if (!rawMsg) {
      await react(sock, m, '❌');
      return m.reply(fromCache ?
        '❌ Tidak ada di cache sock.chats.\nPesan mungkin dikirim sebelum bot online, atau cache sudah ter-replace.' :
        '❌ Tidak bisa ambil raw message dari store/vM/cache/quoted manapun.');
    }

    const msgType = getMsgType(rawMsg);
    const forceFile = flag.includes('-file') || flag.includes('-run');
    const sender = quoted.sender || quoted.participant || '-';
    const size = getSize(rawMsg);
    const keys = countKeys(rawMsg);
    const tsRaw = getTimestamp(quoted, rawMsg, msgType);
    const ts = tsRaw ? new Date(tsRaw * 1000).toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta'
    }) : '-';

    const meta = `• Type    : ${msgType}
• Source  : ${source}${chain.length ? ` (unwrapped: ${chain.join(' > ')})` : ''}
• Chat    : ${shortStr(chat)}
• ID      : ${id}
• Sender  : ${sender.replace('@s.whatsapp.net', '')}
• Time    : ${ts}
• Size    : ${size}  Keys: ${keys}`;

    const wantSnip = flag.includes('-snip');

    let result = null;

    if (flag.includes('-meta')) {
      const stats = {
        count: 0
      };
      let clone;
      try {
        clone = JSON.parse(JSON.stringify(rawMsg));
      } catch {
        clone = rawMsg;
      }
      const decodedMsg = deepDecode(clone, stats);
      result = {
        heading: '# 🧠 Deep Meta Decode',
        pills: ['meta-decode', msgType, chat, id],
        code: safeJson(decodedMsg),
        language: 'json',
        fileTag: 'meta',
        fileExt: 'json',
        metaExtra: `• Status  : ${stats.count > 0 ? `✅ ${stats.count} data tersembunyi ter-decode (JSON-string/JWT/Base64 → JSON)` : '⚠️ Tidak ada data tersembunyi yang bisa di-decode'}`
      };
    } else if (flag.includes('-info')) {
      result = {
        heading: '# 📋 Message Info',
        pills: [msgType, chat, id],
        code: meta,
        language: 'text',
        fileTag: 'info',
        fileExt: 'txt'
      };
    } else if (flag.includes('-key')) {
      const key = getQuotedKey(sock, quoted, chat, sender, id);
      result = {
        heading: '# 🔑 Message Key',
        pills: [msgType, chat, id],
        code: safeJson(key),
        language: 'json',
        fileTag: 'key',
        fileExt: 'json'
      };
    } else if (flag.includes('-ctx')) {
      const ctx = (rawMsg[msgType] || {}).contextInfo || rawMsg?.contextInfo || null;
      if (!ctx) {
        await react(sock, m, '❌');
        return m.reply('❌ Tidak ada contextInfo di pesan ini.');
      }
      result = {
        heading: '# 📎 Context Info',
        pills: [msgType, chat, id],
        code: safeJson(ctx),
        language: 'json',
        fileTag: 'ctx',
        fileExt: 'json'
      };
    } else if (flag.includes('-type')) {
      await m.reply(`📌 *Type:* \`${msgType}\`\n📦 *Size:* ${size}\n🔢 *Keys:* ${keys}`);
      return react(sock, m, '✅');
    } else if (flag.includes('-relay')) {
      result = {
        heading: '# 🎯 Relay Target (jid)',
        pills: [msgType, chat, id],
        code: safeJson(chat),
        language: 'json',
        fileTag: 'relay-jid',
        fileExt: 'json'
      };
    } else {
      const {
        nodes: addNodes
      } = getAdditionalNodes(quoted, rawMsg, msgType);

      if (flag.includes('-option')) {
        const relayOption = addNodes ? {
          additionalNodes: addNodes
        } : {};
        result = {
          heading: '# ⚙️ Relay Options',
          pills: [msgType, chat, id],
          code: safeJson(relayOption),
          language: 'json',
          fileTag: 'relay-option',
          fileExt: 'json'
        };
      } else {
        const fixedContent = normalizePayloadForRelay(rawMsg);

        if (flag.includes('-message')) {
          result = {
            heading: '# 📨 Relay Message Content',
            pills: [msgType, chat, id],
            code: safeJson(fixedContent),
            language: 'json',
            fileTag: 'relay-message',
            fileExt: 'json'
          };
        } else {
          let relayOptionsStr = '{}';
          if (addNodes) {
            relayOptionsStr = safeJson({
              additionalNodes: addNodes
            }, 2);
          }
          const execCode = `await sock.relayMessage(
  m.chat,
  ${safeJson(fixedContent, 2, 0, '', true)},
  ${relayOptionsStr}
);`;
          result = {
            heading: `# ⚡ ${capitalize(msgType)} Relay Snippet`,
            pills: [msgType, chat, id],
            code: execCode,
            language: 'javascript',
            fileTag: 'snip',
            fileExt: 'js',
            fileTrailer: buildPayloadBlock(fixedContent, addNodes ? {
              additionalNodes: addNodes
            } : {})
          };
        }
      }
    }

    const fullMeta = result.metaExtra ? `${meta}\n${result.metaExtra}` : meta;
    const fileCaption = `${result.heading.replace(/^#+\s*/, '')}\n\n${fullMeta}`;

    if (wantSnip) {
      await sendAsCode(sock, m, {
        heading: result.heading,
        meta: fullMeta,
        pills: result.pills,
        code: result.code,
        language: result.language
      });
    } else if (forceFile) {
      await sendAsFile(sock, m, result.fileTrailer ? `${result.code}\n\n${result.fileTrailer}` : result.code, result.fileTag, result.fileExt, fileCaption, msgType);
    } else {
      await sendAuto(sock, m, {
        heading: result.heading,
        meta: fullMeta,
        pills: result.pills,
        code: result.code,
        language: result.language,
        fileTag: result.fileTag,
        fileExt: result.fileExt,
        fileCaption,
        msgType,
        forceFile,
        fileTrailer: result.fileTrailer
      });
    }
    return react(sock, m, '✅');

  } catch (e) {
    console.error('[crm]', e);
    await react(sock, m, '❌');
    return m.reply(`❌ ${e.message}`);
  }
}

async function runInsp(m, ctx) {
  return runCrm(m, {
    ...ctx,
    args: ['-info', ...ctx.args]
  }, {
    fromCache: false
  });
}

async function runAdn(m, {
  sock,
  args
}) {
  if (!m.quoted) return m.reply(HELP);
  await react(sock, m, '⏳');

  try {
    const quoted = m.quoted;
    const {
      msg: rawMsg,
      source,
      chain
    } = await getRawMsg(sock, quoted);

    if (!rawMsg) {
      await react(sock, m, '❌');
      return m.reply('❌ Tidak bisa ambil raw message dari store/vM/cache/quoted manapun.');
    }

    const chat = quoted.chat || m.chat || '-';
    const id = quoted.id || '-';
    const msgType = getMsgType(rawMsg);
    const flag = args.join(' ').toLowerCase().trim();
    const nofilter = flag.includes('-nofilter');
    const wantSnip = flag.includes('-snip');

    const {
      nodes,
      synthetic
    } = getAdditionalNodes(quoted, rawMsg, msgType);

    if (!nodes) {
      await react(sock, m, '❌');
      return m.reply('❌ Tidak ada additionalNodes yang ketemu di proto ini.');
    }

    const shaped = nofilter ? nodes : fixEnums(nodes);
    const meta = `• Type    : ${msgType}
• Source  : ${source}${chain.length ? ` (unwrapped: ${chain.join(' > ')})` : ''}
• Filter  : ${nofilter ? 'off (-nofilter)' : 'on'}
• Origin  : ${synthetic ? 'synthetic fallback' : 'extracted from message'}`;

    if (wantSnip) {
      const code = `const additionalNodes = ${safeJson(shaped)};`;
      await sendAuto(sock, m, {
        heading: `# 🍔 ${capitalize(msgType)} AdditionalNode Snippet`,
        meta,
        pills: [msgType, chat, id],
        code,
        language: 'javascript',
        fileTag: 'adn-snip',
        fileExt: 'js',
        fileCaption: '⚡ *AdditionalNode Snippet*',
        msgType
      });
      return react(sock, m, '✅');
    }

    await sendAuto(sock, m, {
      heading: '# 🍔 AdditionalNodes',
      meta,
      pills: [msgType, chat, id],
      code: safeJson(shaped),
      language: 'json',
      fileTag: 'adn',
      fileExt: 'json',
      fileCaption: '🍔 *AdditionalNodes*',
      msgType
    });
    return react(sock, m, '✅');

  } catch (e) {
    console.error('[adn]', e);
    await react(sock, m, '❌');
    return m.reply(`❌ ${e.message}`);
  }
}

async function runRelay(m, {
  sock,
  args
}) {
  if (!m.quoted) return m.reply(HELP);
  await react(sock, m, '⏳');

  try {
    const quoted = m.quoted;
    const {
      msg: rawMsg
    } = await getRawMsg(sock, quoted);

    if (!rawMsg) {
      await react(sock, m, '❌');
      return m.reply('❌ Tidak bisa ambil raw message dari store/vM/cache/quoted manapun.');
    }

    const flags = args.map(a => a.toLowerCase());
    const sameKey = flags.includes('-samekey');
    const targetJid = args.find(a => !a.startsWith('-')) || m.chat;
    const msgType = getMsgType(rawMsg);

    const fixedContent = normalizePayloadForRelay(rawMsg);

    const {
      nodes: addNodes
    } = getAdditionalNodes(quoted, rawMsg, msgType);

    const relayOptions = {
      ...(sameKey ? {
        messageId: quoted.id
      } : {}),
      ...(addNodes ? {
        additionalNodes: addNodes
      } : {})
    };

    await sock.relayMessage(targetJid, fixedContent, relayOptions);

    return react(sock, m, '✅');

  } catch (e) {
    console.error('[relay]', e);
    await react(sock, m, '❌');
    return m.reply(`❌ Gagal relay: ${e.message}`);
  }
}

let handler = async (m, ctx) => {
  const cmd = String(ctx.command || '').toLowerCase();
  if (cmd === 'crm2') return runCrm(m, ctx, {
    fromCache: true
  });
  if (cmd === 'insp') return runInsp(m, ctx);
  if (cmd === 'adn') return runAdn(m, ctx);
  if (cmd === 'relay') return runRelay(m, ctx);
  return runCrm(m, ctx, {
    fromCache: false
  });
};

export { pluginConfig as config, handler };