import te from '../../src/lib/ichigo-error.js'
import { normalizeMessageContent, getContentType } from 'ichigo'

const pluginConfig = {
    name: 'quoted',
    alias: ['q'],
    category: 'tools',
    description: 'Forward ulang pesan nested (pesan yang di-reply dari pesan yang kamu reply)',
    usage: '.quoted (reply pesan)',
    isOwner: false,
    cooldown: 3,
    isEnabled: true
}

async function handler(m, { sock } = {}) {
    if (!m.quoted) {
        return m.reply('❌ *Reply pesan yang ingin di-forward*')
    }

    try {
        // m.quoted.message adalah raw message content dari pesan yang di-reply
        const quotedRaw = m.quoted.message
        const quotedType = m.quoted.type
        const quotedContent = quotedRaw?.[quotedType]
        const nestedCtx = quotedContent?.contextInfo

        if (!nestedCtx?.quotedMessage) {
            return m.reply('❌ *Pesan yang kamu reply tidak mengandung reply lain*')
        }

        // Pesan nested (pesan yang di-reply oleh pesan yang kamu reply)
        const nestedMessage = normalizeMessageContent(nestedCtx.quotedMessage) || nestedCtx.quotedMessage

        if (!sock) {
            return m.reply('❌ *Fitur ini butuh akses sock, cek signature handler plugin*')
        }

        await sock.sendMessage(m.chat, {
            forward: {
                key: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: nestedCtx.stanzaId || '',
                    participant: nestedCtx.participant || undefined
                },
                message: nestedMessage
            },
            force: true
        })
    } catch (err) {
        console.log(err)
        await m.reply(te(m.prefix, m.command, m.pushName))
    }
}

export { pluginConfig as config, handler }