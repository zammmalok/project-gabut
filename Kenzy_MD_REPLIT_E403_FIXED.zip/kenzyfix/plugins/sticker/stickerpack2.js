import config from '../../config.js'
import te from '../../src/lib/ichigo-error.js'
import {
    getManualQueue,
    clearManualQueue,
    buildAndSendPack
} from '../../src/lib/ichigo-sticker-queue.js'

const pluginConfig = {
    name: 'stickerpack2',
    alias: ['sp', 'spack'],
    category: 'sticker',
    description: 'Kumpulin beberapa gambar lalu jadikan satu Sticker Pack dengan nama custom. Support kirim banyak foto sekaligus (album) dengan caption ".sp create Nama | Author"',
    usage: '.sp add (reply gambar)\n.sp create <nama pack> | <author>\n.sp clear\n.sp status\natau: kirim banyak foto sekaligus + caption ".sp create Nama | Author"',
    example: '.sp add\n.sp create Pack Ku | Aku\n.sp status\n.sp clear',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock, config: botConfig }) {
    const sub = (m.args?.[0] || '').toLowerCase()
    const key = m.sender

    if (sub === 'add') {
        const isImage = m.isImage || (m.quoted && m.quoted.type === 'imageMessage')
        if (!isImage) {
            await m.reply('❌ Reply/kirim gambar dengan caption `.sp add`')
            await m.react('❌')
            return
        }

        await m.react('🕕')
        try {
            const buffer = m.quoted && m.quoted.isMedia ? await m.quoted.download() : await m.download()
            if (!buffer) {
                await m.reply('❌ Gagal mendownload gambar!')
                await m.react('❌')
                return
            }
            const list = getManualQueue(key)
            list.push(buffer)
            await m.reply(`✅ Gambar ditambahkan (${list.length} total di antrian)\n\nLanjut tambah gambar lain, atau ketik:\n\`${m.prefix}sp create NamaPack | Author\``)
            await m.react('✅')
        } catch (error) {
            m.reply(te(m.prefix, m.command, m.pushName))
            await m.react('❌')
        }
        return
    }

    if (sub === 'status') {
        const count = getManualQueue(key).length
        await m.reply(`📦 Antrian sticker pack kamu: *${count}* gambar`)
        return
    }

    if (sub === 'clear') {
        clearManualQueue(key)
        await m.reply('🗑️ Antrian sticker pack dikosongkan.')
        return
    }

    if (sub === 'create') {
        const rest = (m.args || []).slice(1).join(' ')
        const [packname, author] = rest.split('|').map(s => s?.trim())

        if (!packname) {
            await m.reply(`❌ Format: \`${m.prefix}sp create Nama Pack | Nama Author\``)
            return
        }

        let list = getManualQueue(key)

        const isReplyImage = m.quoted && (m.quoted.isImage || m.quoted.type === 'imageMessage')
        const isDirectImage = !m.quoted && m.isImage

        if (!list.length && (isReplyImage || isDirectImage)) {
            await m.react('🕕')
            try {
                const buffer = isReplyImage ? await m.quoted.download() : await m.download()
                if (buffer) list = [buffer]
            } catch (e) { }
        }

        if (!list.length) {
            await m.reply(`❌ Antrian masih kosong. Reply gambar dengan \`${m.prefix}sp create Nama | Author\`, tambah satu-satu lewat \`${m.prefix}sp add\`, atau kirim banyak foto sekaligus (album) dengan caption \`${m.prefix}sp create Nama | Author\``)
            return
        }

        await m.react('🕕')
        try {
            const finalAuthor = author || botConfig.sticker?.author || botConfig.owner?.name || 'Bot'
            await buildAndSendPack(sock, m.chat, list, packname, finalAuthor)
            clearManualQueue(key)
            await m.react('✅')
        } catch (error) {
            m.reply(te(m.prefix, m.command, m.pushName))
            await m.react('❌')
        }
        return
    }

    await m.reply(
        `📦 *sᴛɪᴄᴋᴇʀ ᴘᴀᴄᴋ ᴍᴀᴋᴇʀ*\n\n` +
        `*Cara 1 - kirim banyak foto sekaligus (album):*\n` +
        `Pilih beberapa foto dari galeri, kasih caption:\n> \`${m.prefix}sp create Nama Pack | Nama Author\`\n\n` +
        `*Cara 2 - satu-satu:*\n` +
        `1. Reply gambar satu-satu dengan:\n> \`${m.prefix}sp add\`\n` +
        `2. Kalau sudah cukup, ketik:\n> \`${m.prefix}sp create Nama Pack | Nama Author\`\n\n` +
        `Lainnya:\n> \`${m.prefix}sp status\` - cek jumlah antrian\n> \`${m.prefix}sp clear\` - kosongkan antrian`
    )
}

export { pluginConfig as config, handler }