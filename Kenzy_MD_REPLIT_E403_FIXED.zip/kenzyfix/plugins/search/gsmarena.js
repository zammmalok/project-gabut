import axios from "axios";

const BASE_URL = "https://api.azbry.com/api/search/gsmarena";
const EXCHANGE_URL = "https://api.exchangerate-api.com/v4/latest/USD";

const pluginConfig = {
  name: "gsmarena",
  alias: ["spekhp", "carihp"],
  category: "search",
  description: "Cari spesifikasi lengkap HP dari GSMArena",
  usage: ".gsmarena <nama hp>",
  example: ".gsmarena samsung galaxy a17",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  energi: 1,
  isEnabled: true,
};

function fixImageUrl(url) {
  if (!url) return null;
  return url.replace(/^https?:https?:\/\//, "https://");
}

function getSpec(specs, category, label) {
  const cat = specs?.find((c) => c.category.toLowerCase() === category.toLowerCase());
  const item = cat?.items?.find((i) => i.label.toLowerCase() === label.toLowerCase());
  return item?.value ?? "-";
}

function extractAntutu(perfText) {
  const match = perfText.match(/AnTuTu:\s*([\d,]+)/i);
  return match ? match[1] : "-";
}

function parseUSD(priceStr) {
  const match = priceStr.match(/\$\s*([\d,.]+)/);
  if (!match) return null;
  return parseFloat(match[1].replace(/,/g, ""));
}

function toRupiah(amount) {
  return "Rp " + Math.round(amount).toLocaleString("id-ID");
}

async function getUSDtoIDR() {
  try {
    const { data } = await axios.get(EXCHANGE_URL, { timeout: 10000 });
    return data?.rates?.IDR ?? 17000;
  } catch {
    return 17000; 
  }
}

async function handler(m, { sock }) {
  const query = m.args.join(" ")?.trim();

  if (!query) {
    return m.reply(
      `╭━━━「 📱 *GSMARENA* 」━━━╮
┃  Cari spesifikasi HP favoritmu!
┃
┃  🔎 ${m.prefix}gsmarena <nama hp>
┃  📌 Contoh:
┃  ${m.prefix}gsmarena samsung galaxy a17
╰━━━━━━━━━━━━━━━━━━━╯`
    );
  }

  m.react("🔍");

  try {
    const [searchRes, usdRate] = await Promise.all([
      axios.get(BASE_URL, { params: { q: query }, timeout: 15000 }),
      getUSDtoIDR(),
    ]);

    if (!searchRes.data.status) throw new Error("API gagal");
    const results = searchRes.data.result?.search ?? [];

    if (!results.length) {
      m.react("❌");
      return m.reply(`❌ Tidak ditemukan HP untuk: *${query}*`);
    }

    const first = results[0];

    const detailRes = await axios.get(BASE_URL, {
      params: { q: query, detail: first.id },
      timeout: 15000,
    });

    if (!detailRes.data.status) throw new Error("API gagal");
    const hp = detailRes.data.result?.detail ?? null;

    if (!hp) {
      m.react("❌");
      return m.reply(`❌ Gagal mengambil detail untuk: *${first.name}*`);
    }

    const s = hp.specs;

    const released   = getSpec(s, "Launch", "Status").replace("Available. ", "");
    const network    = getSpec(s, "Network", "Technology");
    const dim        = getSpec(s, "Body", "Dimensions").split("(")[0].trim();
    const weight     = getSpec(s, "Body", "Weight").split("(")[0].trim();
    const build      = getSpec(s, "Body", "Build");
    const sim        = getSpec(s, "Body", "SIM").replace(/·/g, "").trim();
    const display    = `${getSpec(s, "Display", "Type").split(",")[0]}, ${getSpec(s, "Display", "Size").split(",")[0]}`;
    const resolution = getSpec(s, "Display", "Resolution").split(",")[0];
    const os         = getSpec(s, "Platform", "OS").split(",").slice(0, 2).join(", ");
    const chipset    = getSpec(s, "Platform", "Chipset");
    const cpu        = getSpec(s, "Platform", "CPU");
    const gpu        = getSpec(s, "Platform", "GPU");
    const ram        = getSpec(s, "Memory", "Internal");
    const camera     = getSpec(s, "Main Camera", "Triple").split(" ").slice(0, 3).join(" ");
    const camFeat    = getSpec(s, "Main Camera", "Features");
    const selfie     = getSpec(s, "Selfie camera", "Single").split(",")[0];
    const battery    = getSpec(s, "Battery", "Type");
    const charging   = getSpec(s, "Battery", "Charging");
    const nfc        = getSpec(s, "Comms", "NFC");
    const usb        = getSpec(s, "Comms", "USB");
    const bt         = getSpec(s, "Comms", "Bluetooth");
    const colors     = getSpec(s, "Misc", "Colors");
    const perfRaw    = getSpec(s, "Our Tests", "Performance");
    const antutu     = extractAntutu(perfRaw);

    const pricesText = hp.prices?.map((v) => {
      const priceList = v.prices.map((p) => {
        const usd = parseUSD(p.price);
        const idr = usd ? ` (~${toRupiah(usd * usdRate)})` : "";
        return `${p.price}${idr}`;
      }).join(" / ");
      return `┃  • *${v.variant}:* ${priceList}`;
    }).join("\n") ?? "┃  • -";

    const others = results.length > 1
      ? results.slice(1, 4).map((r, i) => `┃  ${i + 2}. ${r.name}`).join("\n")
      : "";

    const text =
`╭━━━「 📱 *${hp.name}* 」━━━╮
┃
┃ 🗓️ *Rilis:* ${released}
┃ 📡 *Jaringan:* ${network}
┃
┃ 📐 *BODY*
┃  • Dimensi: ${dim}
┃  • Berat: ${weight}
┃  • Build: ${build}
┃  • SIM: ${sim}
┃
┃ 🖥️ *LAYAR*
┃  • ${display}
┃  • ${resolution}
┃
┃ ⚙️ *PLATFORM*
┃  • OS: ${os}
┃  • Chipset: ${chipset}
┃  • CPU: ${cpu}
┃  • GPU: ${gpu}
┃
┃ 💾 *MEMORI*
┃  • ${ram}
┃
┃ 📷 *KAMERA*
┃  • Utama: ${camera}
┃  • Fitur: ${camFeat}
┃  • Selfie: ${selfie}
┃
┃ 🔋 *BATERAI*
┃  • ${battery}, ${charging}
┃
┃ 📶 *KONEKTIVITAS*
┃  • NFC: ${nfc}
┃  • Bluetooth: ${bt}
┃  • USB: ${usb}
┃
┃ 🧪 *BENCHMARK*
┃  • AnTuTu: ${antutu}
┃
┃ 🎨 *Warna:* ${colors}
┃
┃ 💰 *HARGA*
${pricesText}
${others ? "┃\n┃ 🔎 *Hasil lain:*\n" + others + "\n" : ""}┃
╰━━━━━━━━━━━━━━━━━━━╯
🔗 ${hp.url}`;

    const imageUrl = fixImageUrl(hp.image);

    if (imageUrl) {
      try {
        await sock.sendMessage(
          m.chat,
          {
            image: { url: imageUrl },
            caption: text,
            contextInfo: { forwardingScore: 99, isForwarded: true },
          },
          { quoted: m },
        );
      } catch {
        await m.reply(text);
      }
    } else {
      await m.reply(text);
    }

    m.react("✅");
  } catch (error) {
    m.react("☢");
    await m.reply(`❌ Gagal mengambil data: *${query}*\n> ${error.message}`);
  }
}

export { pluginConfig as config, handler };