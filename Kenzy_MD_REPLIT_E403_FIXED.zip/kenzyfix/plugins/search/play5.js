import axios from "axios";
import { AIRich } from "../../src/lib/ichigo-builder.js";
import te from "../../src/lib/ichigo-error.js";

const pluginConfig = {
  name: "play5",
  alias: ["p5", "ytplay5"],
  category: "search",
  description: "Cari lagu di YouTube dan kirim audionya (kartu info + MP3) - versi 5",
  usage: ".play5 <judul lagu>",
  example: ".play5 bye ariana grande",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 15,
  energi: 2,
  isEnabled: true,
};

const API = "https://api-cloud.my.id/downloader/play";
const MAX_AUDIO_BYTES = 40 * 1024 * 1024; // 40 MB
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Buang karakter markdown supaya teks dari YouTube tidak merusak format pesan
function safe(text) {
  return String(text || "").replace(/[\[\]()<>*_`]/g, " ").replace(/\s+/g, " ").trim();
}

// API kadang mengirim durasi "3.04", kadang "3:33" -> samakan jadi "3:04"
function formatDuration(value) {
  const v = String(value || "").trim();
  if (!v) return "-";
  return /^\d+\.\d{2}$/.test(v) ? v.replace(".", ":") : v;
}

function fileNameFor(title) {
  const clean = String(title || "audio").replace(/[\\/:*?"<>|]/g, " ").replace(/\s+/g, " ").trim();
  return `${clean.slice(0, 80) || "audio"}.mp3`;
}

// Cari lagu. Error 5xx dicoba ulang sekali; error jaringan/HTTP dibedakan dari "tidak ditemukan"
async function searchSong(query) {
  let lastErr = null;

  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const res = await axios.get(API, {
        params: { query },
        timeout: 60000,
        headers: { "User-Agent": UA, Accept: "application/json" },
        validateStatus: () => true,
      });

      if (res.status >= 500) {
        lastErr = new Error(`API HTTP ${res.status}`);
        console.error(`[Play5] HTTP ${res.status} (percobaan ${attempt}):`, JSON.stringify(res.data)?.slice(0, 300));
        if (attempt < 2) await sleep(2000);
        continue;
      }
      if (res.status !== 200) {
        console.error(`[Play5] HTTP ${res.status}:`, JSON.stringify(res.data)?.slice(0, 300));
        throw Object.assign(new Error(`API HTTP ${res.status}`), { apiDown: true });
      }
      return res.data;
    } catch (err) {
      if (err.apiDown) throw err;
      lastErr = err;
      console.error(`[Play5] Percobaan ${attempt} gagal:`, err.code || err.message);
      if (attempt < 2) await sleep(2000);
    }
  }

  throw Object.assign(lastErr || new Error("API tidak merespons"), { apiDown: true });
}

async function downloadAudio(url) {
  const res = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 120000,
    maxContentLength: MAX_AUDIO_BYTES,
    headers: { "User-Agent": UA },
  });
  const buffer = Buffer.from(res.data);
  if (!buffer.length) throw new Error("File audio kosong");
  return buffer;
}

async function handler(m, { sock }) {
  const query = (m.text || "").trim();

  if (!query) {
    return m.reply(
      `🎵 *ᴘʟᴀʏ ᴠ5*\n\n` +
        `> Contoh:\n` +
        `\`${m.prefix}${m.command} bye ariana grande\``,
    );
  }

  if (query.length > 150) {
    return m.reply("❌ Judul terlalu panjang, maksimal 150 karakter.");
  }

  await m.react("🕕");

  try {
    const data = await searchSong(query);
    const r = data?.result;

    if (!data?.status || !r?.title) {
      console.error("[Play5] Respons API:", JSON.stringify(data)?.slice(0, 300));
      await m.react("❌");
      return m.reply(`❌ Lagu *${safe(query)}* tidak ditemukan.`);
    }

    const duration = formatDuration(r.duration);
    const videoUrl = r.url || (r.videoId ? `https://www.youtube.com/watch?v=${r.videoId}` : "");

    // ===== Kartu info (gaya sama seperti tiktokstalk2) =====
    const ai = new AIRich(sock);
    ai.setTitle("YouTube Play");

    const entity = {
      __typename: "GenAICompactEntityPrimitive",
      title: String(r.title).slice(0, 100),
      subtitle: `${r.channel || "YouTube"} • ${duration}`,
      secondary_subtitle: "YouTube Music",
      entity_id: String(r.videoId || query),
      entity_url: videoUrl,
      entity_type: "PAGE",
      action_type: "FOLLOW",
      is_verified: false,
    };
    if (r.thumbnail) entity.image = { url: r.thumbnail, url_fallback: r.thumbnail };

    ai.addSection({
      view_model: {
        primitive: entity,
        __typename: "GenAISingleLayoutViewModel",
      },
    });

    ai.addFOAText(
      `🎵 *${safe(r.title)}*\n\n` +
        `📺 Channel: *${safe(r.channel) || "-"}*\n` +
        `⏱️ Durasi: *${duration}*\n` +
        (videoUrl ? `🔗 [Buka di YouTube](${videoUrl})\n` : "") +
        `\n_Audio sedang dikirim..._`,
    );
    if (r.thumbnail) ai.addImage(r.thumbnail);
    ai.addMetadata("Play v5 • By Kenzy MD");

    await ai.send(m.chat, { quoted: m, bypassDownload: true });

    // ===== Kirim audio =====
    if (!r.download) {
      await m.react("❌");
      return m.reply("⚠️ API tidak memberikan link audio untuk lagu ini.");
    }

    let audio;
    try {
      audio = await downloadAudio(r.download);
    } catch (e) {
      console.error("[Play5] Download audio gagal:", e.code || e.message);
      await m.react("❌");
      const tooBig = e.code === "ERR_FR_MAX_CONTENT_LENGTH_EXCEEDED";
      return m.reply(
        tooBig
          ? `⚠️ File audio terlalu besar (maksimal ${MAX_AUDIO_BYTES / 1024 / 1024} MB).`
          : `⚠️ Gagal mengunduh audio. Coba lagi nanti.\n\n> Link langsung: ${r.download}`,
      );
    }

    await sock.sendMessage(
      m.chat,
      {
        audio,
        mimetype: "audio/mpeg",
        fileName: fileNameFor(r.title),
      },
      { quoted: m },
    );
    await m.react("✅");
  } catch (err) {
    console.error("[Play5] Error:", err.message);
    await m.react("☢");
    if (err.apiDown) {
      return m.reply(`⚠️ Server pencarian lagu sedang bermasalah (${err.message}). Coba lagi beberapa saat lagi.`);
    }
    m.reply(te(m.prefix, m.command, m.pushName));
  }
}

export { pluginConfig as config, handler };