import axios from "axios";
import { ytSearch } from "../../src/scraper/ytsearch-safe.js";
import { createCanvas, loadImage } from "@napi-rs/canvas";
import config from "../../config.js";
import te from "../../src/lib/ichigo-error.js";
import ytdl2 from "../../src/scraper/ytdl2.js";

const pluginConfig = {
  name: "playch",
  alias: ["pch", "playsaluran"],
  category: "search",
  description: "Putar musik ke saluran (convert opus)",
  usage: ".playch <query> | .playch --idch <id> <query>",
  example: ".playch komang",
  cooldown: 15,
  energi: 1,
  isEnabled: true,
};

function pickVideo(search) {
  const v = search?.videos || [];
  return v.find((x) => x.duration?.seconds && x.duration.seconds < 900) || v[0] || null;
}

function parseArtistTitle(video) {
  const raw = (video.title || "Unknown").trim();
  const seps = [" - ", " – ", " — ", " | "];
  for (const sep of seps) {
    if (raw.includes(sep)) {
      const [first, ...rest] = raw.split(sep);
      const artist = first.trim();
      const title = rest.join(sep).trim();
      if (artist && title) return { artist, title };
    }
  }
  return {
    artist: video.author?.name || video.author?.username || "Unknown Artist",
    title: raw,
  };
}

const DOWNLOAD_TIMEOUT_MS = 55_000;
const MAX_RETRIES = 1;

function withTimeout(promiseFactory, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("TIMEOUT")), ms);

    promiseFactory()
      .then((res) => {
        clearTimeout(timer);
        resolve(res);
      })
      .catch((err) => {
        clearTimeout(timer);
        reject(err);
      });
  });
}

async function withRetry(fn, { retries = MAX_RETRIES, timeoutMs = DOWNLOAD_TIMEOUT_MS } = {}) {
  let lastErr;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await withTimeout(fn, timeoutMs);
    } catch (err) {
      lastErr = err;
      const isTimeout = err?.message === "TIMEOUT";
      if (!isTimeout || attempt === retries) throw err;
      continue;
    }
  }
  throw lastErr;
}

function truncateText(ctx, text, maxWidth) {
  if (ctx.measureText(text).width <= maxWidth) return text;
  let t = text;
  while (t.length > 1 && ctx.measureText(t + "…").width > maxWidth) {
    t = t.slice(0, -1);
  }
  return t + "…";
}

function wrapLines(ctx, text, maxWidth, maxLines) {
  const words = text.split(" ");
  const lines = [];
  let line = "";

  for (const word of words) {
    const test = line ? `${line} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && line) {
      lines.push(line);
      line = word;
      if (lines.length === maxLines - 1) break;
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);

  if (lines.length === maxLines && words.join(" ") !== lines.join(" ")) {
    lines[maxLines - 1] = truncateText(ctx, lines[maxLines - 1], maxWidth);
  }

  return lines.slice(0, maxLines);
}

function drawEqualizer(ctx, x, y, color) {
  const bars = [6, 12, 8, 14, 5];
  let bx = x;
  for (const h of bars) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.roundRect(bx, y - h, 3, h, 1.5);
    ctx.fill();
    bx += 6;
  }
  return bx - x;
}

function drawPlayIcon(ctx, cx, cy, r) {
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,0.35)";
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.6)";
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  const s = r * 0.55;
  ctx.moveTo(cx - s * 0.4, cy - s);
  ctx.lineTo(cx - s * 0.4, cy + s);
  ctx.lineTo(cx + s * 0.9, cy);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

async function buildNowPlayingCard({ thumbnail, title, artist, duration, chName }) {
  const W = 1000, H = 460;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  const bg = ctx.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, "#0b1220");
  bg.addColorStop(0.55, "#141b33");
  bg.addColorStop(1, "#1e2a4a");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  ctx.save();
  ctx.globalAlpha = 0.14;
  ctx.fillStyle = "#60a5fa";
  ctx.beginPath();
  ctx.arc(W - 40, 10, 150, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 0.08;
  ctx.fillStyle = "#a855f7";
  ctx.beginPath();
  ctx.arc(60, H + 10, 130, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  ctx.fillStyle = "rgba(255,255,255,0.045)";
  ctx.beginPath();
  ctx.roundRect(20, 20, W - 40, H - 40, 22);
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.09)";
  ctx.lineWidth = 1;
  ctx.stroke();

  const thumbSize = H - 100;
  const thumbX = 46, thumbY = 50;

  ctx.save();
  ctx.shadowColor = "rgba(0,0,0,0.5)";
  ctx.shadowBlur = 30;
  ctx.shadowOffsetY = 10;
  ctx.fillStyle = "#000000";
  ctx.beginPath();
  ctx.roundRect(thumbX, thumbY, thumbSize, thumbSize, 20);
  ctx.fill();
  ctx.restore();

  let thumbImg = null;
  try {
    thumbImg = await loadImage(thumbnail);
  } catch {}

  if (thumbImg) {
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(thumbX, thumbY, thumbSize, thumbSize, 20);
    ctx.clip();
    const scale = Math.max(thumbSize / thumbImg.width, thumbSize / thumbImg.height);
    const iw = thumbImg.width * scale, ih = thumbImg.height * scale;
    ctx.drawImage(thumbImg, thumbX - (iw - thumbSize) / 2, thumbY - (ih - thumbSize) / 2, iw, ih);

    const shade = ctx.createLinearGradient(0, thumbY, 0, thumbY + thumbSize);
    shade.addColorStop(0, "rgba(0,0,0,0)");
    shade.addColorStop(1, "rgba(0,0,0,0.35)");
    ctx.fillStyle = shade;
    ctx.fillRect(thumbX, thumbY, thumbSize, thumbSize);
    ctx.restore();
  } else {
    ctx.fillStyle = "rgba(255,255,255,0.08)";
    ctx.beginPath();
    ctx.roundRect(thumbX, thumbY, thumbSize, thumbSize, 20);
    ctx.fill();
  }

  ctx.strokeStyle = "rgba(255,255,255,0.18)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(thumbX, thumbY, thumbSize, thumbSize, 20);
  ctx.stroke();

  drawPlayIcon(ctx, thumbX + thumbSize / 2, thumbY + thumbSize / 2, 30);

  const textX = thumbX + thumbSize + 34;
  const textW = W - textX - 40;

  const blockOffset = 60;

  ctx.fillStyle = "#60a5fa";
  ctx.font = "bold 14px sans-serif";
  const eqW = drawEqualizer(ctx, textX, thumbY + 22 + blockOffset, "#60a5fa");
  ctx.fillText("NOW PLAYING · SALURAN", textX + eqW + 10, thumbY + 24 + blockOffset);

  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 32px sans-serif";
  const titleLines = wrapLines(ctx, title, textW, 2);
  titleLines.forEach((line, i) => {
    ctx.fillText(line, textX, thumbY + 68 + blockOffset + i * 40);
  });

  const artistY = thumbY + 68 + blockOffset + titleLines.length * 40 + 6;
  ctx.fillStyle = "#94a3b8";
  ctx.font = "18px sans-serif";
  ctx.fillText(truncateText(ctx, artist, textW), textX, artistY);

  const badgeY = artistY + 22;

  ctx.font = "bold 13px sans-serif";
  const durLabel = `⏱ ${duration}`;
  const durW = ctx.measureText(durLabel).width + 26;
  ctx.fillStyle = "rgba(96,165,250,0.18)";
  ctx.beginPath();
  ctx.roundRect(textX, badgeY, durW, 28, 14);
  ctx.fill();
  ctx.strokeStyle = "rgba(96,165,250,0.35)";
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = "#93c5fd";
  ctx.fillText(durLabel, textX + 13, badgeY + 19);

  const chLabel = truncateText(ctx, `📡 ${chName}`, textW - durW - 12);
  const chW = ctx.measureText(chLabel).width + 26;
  ctx.fillStyle = "rgba(255,255,255,0.08)";
  ctx.beginPath();
  ctx.roundRect(textX + durW + 10, badgeY, chW, 28, 14);
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.12)";
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = "#e2e8f0";
  ctx.fillText(chLabel, textX + durW + 23, badgeY + 19);

  return canvas.toBuffer("image/png");
}


async function getPlayChAudioDownload(url) {
  const result = await withRetry(() => ytdl2(url, "mp3"));

  if (!result?.status || !result?.download) {
    throw new Error(result?.mess || "Gagal mendapatkan audio saluran URL");
  }

  return { download: result.download, title: result.title };
}

async function handler(m, { sock }) {
  const raw = m.text?.trim() || "";
  let chId = config?.saluran?.id;
  let chName = config?.saluran?.name || config?.bot?.name || "Kenzy MD";
  let q = raw;

  const idchMatch = raw.match(/--idch\s+(\S+)/);
  if (idchMatch) {
    chId = idchMatch[1];
    chName = chId;
    q = raw.replace(/--idch\s+\S+/, "").trim();
  }

  if (!q)
    return m.reply(
      `🎵 *PLAY SALURAN*\n\n` +
      `\`${m.prefix}playch <judul lagu>\`\n` +
      `\`${m.prefix}playch --idch <id_saluran> <judul lagu>\``,
    );

  if (!chId)
    return m.reply(`❌ Saluran belum diatur. Gunakan \`--idch <id>\` atau atur di config.js`);

  m.react("🔎");

  try {
    const { videos } = await ytSearch(q);
    const video = pickVideo({ videos });
    if (!video) return m.reply(`❌ Video tidak ditemukan`);

    const ytChannel = video.author?.name || video.author?.username || "Unknown";
    const { artist, title } = parseArtistTitle(video);
    const duration = video.duration?.timestamp || "0:00";

    const info =
      `╭─ 🎵 *NOW PLAYING (SALURAN)*\n` +
      `│·📌 Judul   : ${video.title}\n` +
      `│·👤 Channel : ${ytChannel}\n` +
      `│·⏱️ Durasi  : ${duration}\n` +
      `│·👀 Views   : ${video.views || "-"}\n` +
      `│·📅 Upload  : ${video.ago || "-"}\n` +
      `│·🆔 ID      : \`${video.videoId}\`\n` +
      `│·📡 Saluran : \`${chId}\`\n` +
      `│·🔗 Link    : ${video.url}\n` +
      `╰───────────────────────────\n` +
      `_⏳ Mengirim audio ke saluran, harap tunggu..._`;

    await sock.sendPreview(
      m.chat,
      {
        caption: info,
        url: video.url,
        title: video.title,
        description: "YouTube Video",
        image: video.thumbnail,
        previewType: 1,
      },
      { quoted: m }
    );

    let audio;
    try {
      audio = await getPlayChAudioDownload(video.url);
    } catch (scrapeErr) {
      if (scrapeErr?.message === "TIMEOUT") {
        await m.react("⏰");
        return m.reply("⏰ *Server YouTube lagi lemot/timeout* saat ambil audio. Coba `.playch` lagi beberapa saat lagi.");
      }
      throw scrapeErr;
    }

    m.react("🎵");

    const caption =
      `╭➤─┈───┈──✦➤\n` +
      `┆ Judul : ${title}\n` +
      `┆ Artist : ${artist}\n` +
      `┆ Durasi : ${duration}\n` +
      `┆ Saluran : ${chName}\n` +
      `╰─➤─┈───┈───┈`;

    const cardBuffer = await buildNowPlayingCard({
      thumbnail: video.thumbnail,
      title,
      artist,
      duration,
      chName,
    });

    await sock.sendMessage(chId, {
      image: cardBuffer,
      caption,
    });

    const mp3Buf = Buffer.from(
      (await axios.get(audio.download, { responseType: "arraybuffer", timeout: 60000 })).data,
    );

    if (mp3Buf.length < 50000) throw new Error("Audio terlalu kecil");

    await sock.sendMessage(chId, {
      audio: mp3Buf,
      mimetype: "audio/mpeg",
      ptt: true,
      contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: chId,
          serverMessageId: Math.floor(Math.random() * 9999),
          newsletterName: `${artist} - ${title}`,
        },
      },
    });

    m.react("✅");
    m.reply(`✅ *${title}* berhasil dikirim ke saluran`);
  } catch (e) {
    console.error("[PlayCh]", e);
    m.react("☢");
    m.reply(te(m.prefix, m.command, m.pushName));
  }
}

export { pluginConfig as config, handler };