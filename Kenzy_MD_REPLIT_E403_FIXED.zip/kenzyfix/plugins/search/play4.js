import axios from "axios";
import { ytSearch, ytSearchVideo } from "../../src/scraper/ytsearch-safe.js";
import { Button, Carousel } from "../../src/lib/ichigo-builder.js";
import te from "../../src/lib/ichigo-error.js";
import ytdl2 from "../../src/scraper/ytdl2.js";

const pluginConfig = {
  name: "play4",
  alias: ["playcarousel", "vplay4"],
  category: "search",
  description: "Cari & putar musik dari YouTube dengan tampilan carousel (multi pilihan)",
  usage: ".play4 <query>",
  example: ".play4 komang",
  cooldown: 15,
  energi: 1,
  isEnabled: true,
};

const MAX_RESULTS = 5;

const DOWNLOAD_TIMEOUT_MS = 25_000;
const MAX_RETRIES = 1;

const YOUTUBE_URL_REGEX = /(?:v=|youtu\.be\/|shorts\/)([a-zA-Z0-9_-]{11})/;

function withTimeout(promiseFactory, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("TIMEOUT")), ms);
    promiseFactory()
      .then((res) => {
        clearTimeout(timer);
        resolve(res);
      })
      .catch((err) => {
        clearTimeout(timer);
        reject(err);
      });
  });
}

async function withRetry(fn, { retries = MAX_RETRIES, timeoutMs = DOWNLOAD_TIMEOUT_MS } = {}) {
  let lastErr;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await withTimeout(fn, timeoutMs);
    } catch (err) {
      lastErr = err;
      const isTimeout = err?.message === "TIMEOUT";
      if (!isTimeout || attempt === retries) throw err;
      continue;
    }
  }
  throw lastErr;
}

/**
 * ytdl2() sekarang ambil link dari CDN SaveTube (bukan lagi toptu.pl/y2jar),
 * dan URL yang dikembalikan belum tentu langsung siap/valid — jadi kita
 * fetch dulu jadi buffer + validasi content-type & ukuran sebelum dikirim
 * ke WhatsApp. Ini yang memperbaiki bug durasi audio 0:00 — sebelumnya
 * URL dikirim langsung ke sendMedia tanpa pernah benar-benar dibaca isinya,
 * jadi client WA tidak bisa menghitung durasi/waveform.
 */
async function downloadAudioBuffer(url) {
  const res = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: DOWNLOAD_TIMEOUT_MS,
    headers: { "User-Agent": "Mozilla/5.0" },
  });

  const contentType = res.headers["content-type"] || "";
  const buffer = Buffer.from(res.data);

  if (!contentType.includes("audio") && !contentType.includes("octet-stream")) {

    const preview = buffer.toString("utf8", 0, Math.min(buffer.length, 200));
    console.error("[Play4] Link bukan audio, content-type:", contentType, "| body:", preview);
    const err = new Error(`Response bukan file audio (content-type: ${contentType})`);
    err.isBadContentType = true;
    throw err;
  }
  if (buffer.length < 5000) {
    throw new Error("File audio kosong/terlalu kecil, kemungkinan link belum siap.");
  }

  return buffer;
}

/**
 * Ambil link download + buffer audio dalam satu alur. Kalau link pertama
 * ternyata basi (content-type bukan audio), minta link BARU ke ytdl2()
 * lagi — retry ke URL yang sama percuma karena link CDN SaveTube yang
 * sudah expired pasti gagal lagi.
 */
async function fetchAudioWithFreshLink(youtubeUrl, { attempts = 2 } = {}) {
  let lastErr;
  for (let i = 0; i < attempts; i++) {
    const scrapeResult = await withRetry(() => ytdl2(youtubeUrl, "mp3"));
    if (!scrapeResult || !scrapeResult.status || !scrapeResult.download) {
      throw new Error(scrapeResult?.mess || "Scraper gagal mengekstrak audio dari video ini.");
    }
    try {
      const buffer = await downloadAudioBuffer(scrapeResult.download);
      return { scrapeResult, buffer };
    } catch (err) {
      lastErr = err;
      console.error(`[Play4][fetchAudioWithFreshLink] percobaan ${i + 1}/${attempts} gagal:`, err.message);
      if (i < attempts - 1) await new Promise((resolve) => setTimeout(resolve, 800));
    }
  }
  throw lastErr;
}

function extractVideoId(url) {
  return String(url || "").match(YOUTUBE_URL_REGEX)?.[1] || url;
}

async function handler(m, { sock }) {
  const query = m.text?.trim();
  const prefix = m.prefix || ".";

  const isDirectUrl = YOUTUBE_URL_REGEX.test(query || "");

  if (isDirectUrl) {
    await m.react("⏳");
    try {
      const video = await ytSearchVideo(extractVideoId(query));
      if (!video?.title) throw new Error("Video tidak ditemukan.");

      let scrapeResult, audioBuffer;
      try {
        ({ scrapeResult, buffer: audioBuffer } = await fetchAudioWithFreshLink(query));
      } catch (dlErr) {
        const isTimeout = dlErr?.message === "TIMEOUT";
        await m.react("⏰");
        return m.reply(
          isTimeout
            ? "⏰ Server YouTube lagi lemot/timeout saat ambil audio. Coba lagi ya."
            : `⚠️ Gagal memproses audio.\n\n> ${dlErr.message}`
        );
      }

      await sock.sendMedia(m.chat, audioBuffer, null, m, {
        type: "audio",
        mimetype: "audio/mpeg",
        ptt: false,
        fileName: `${scrapeResult.title || video.title || "audio"}.mp3`,
      });

      await m.react("✅");
    } catch (err) {
      console.error("[Play4 Download Error]", err);
      await m.react("😭");
      m.reply(`⚠️ Gagal memproses audio.\n\n> Error: ${err.message}`);
    }
    return;
  }

  if (!query) {
    return m.reply(`🎵 *PLAY CAROUSEL*\n\n> Contoh:\n\`${prefix}play4 komang\``);
  }

  await m.react("🔎");

  try {
    const search = await ytSearch(query);
    const results = search?.videos?.slice(0, MAX_RESULTS);

    if (!results || results.length === 0) {
      await m.react("❌");
      return m.reply("❌ Lagu tidak ditemukan di YouTube.");
    }

    const carousel = new Carousel(sock)
      .setBody(`🎵 Hasil pencarian: *${query}*`)
      .setFooter("Swipe untuk lihat pilihan lain • Tekan tombol untuk download audio");

    for (const video of results) {
      const title = video.title.length > 60 ? video.title.slice(0, 57) + "..." : video.title;

      const card = await new Button(sock)
        .setTitle(title)
        .setBody(`⏱️ ${video.duration.timestamp} • 🎙️ ${video.author.name}`)
        .setFooter("YouTube")
        .setImage(video.thumbnail)
        .addReply("🎧 Ambil Audio", `${prefix}play4 ${video.url}`, { icon: "DEFAULT" })
        .addUrl("▶️ Buka di YouTube", video.url, true, { icon: "REVIEW" })
        .toCard();

      carousel.addCard(card);
    }

    await carousel.send(m.chat, { quoted: m });
    await m.react("✅");
  } catch (err) {
    console.error("[Play4 Search Error]", err);
    await m.react("😭");
    m.reply(te(m.prefix, m.command, m.pushName));
  }
}

export { pluginConfig as config, handler };