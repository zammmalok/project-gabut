
import axios from "axios";
import te from "../../src/lib/ichigo-error.js";

const config = {
  name: "tiktoksearch2",
  alias: ["ttsearch2", "carittv2", "searchtiktok2"],
  category: "search",
  description: "Cari video TikTok berdasarkan kata kunci",
  usage: ".tiktoksearch2 <kata kunci>",
  example: ".tiktoksearch2 anime",
  cooldown: 5,
  energi: 1,
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  isEnabled: true,
};

function fmtNum(n) {
  if (!n && n !== 0) return "0";
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1) + "K";
  return n.toLocaleString("id-ID");
}

async function fetchTiktokSearch(query) {
  const { data } = await axios.get(
    "https://api.lexcode.biz.id/api/search/tiktok",
    { params: { q: query }, timeout: 20000 },
  );
  if (!data?.success || !data?.results?.length)
    throw new Error(data?.message || "Tidak ada hasil ditemukan.");
  return data;
}

async function handler(m, { sock }) {
  const query = (m.text || m.fullArgs || "").trim();

  if (!query) {
    return m.reply(
      `╭─ 🔍 *TIKTOK SEARCH*\n` +
      `│· Usage  : \`${m.prefix}tiktoksearch2 <kata kunci>\`\n` +
      `│· Contoh : \`${m.prefix}tiktoksearch2 anime\`\n` +
      `╰───────────────────────────`,
    );
  }

  await m.react("⏳");

  try {
    const data = await fetchTiktokSearch(query);
    const { total, results } = data;

    let text =
      `╭─ 🔍 *TIKTOK SEARCH*\n` +
      `│· Query  : ${query}\n` +
      `│· Total  : ${total} video\n` +
      `╰───────────────────────────\n\n`;

    for (const v of results) {
      const { no, description, url, author, stats, music } = v;
      const desc = description.length > 80
        ? description.slice(0, 80) + "..."
        : description;

      text +=
        `*${no}. @${author.username}*\n` +
        `📝 ${desc}\n` +
        `👁️ ${fmtNum(stats.views)}  ❤️ ${fmtNum(stats.likes)}  💬 ${fmtNum(stats.comments)}  🔁 ${fmtNum(stats.shares)}\n` +
        `🎵 ${music.title} — ${music.artist}\n` +
        `🔗 ${url}\n\n`;
    }

    text += `_🔎 Powered by LexCode API_`;

    await sock.sendMessage(
      m.chat,
      { text },
      { quoted: m },
    );

    await m.react("✅");

  } catch (e) {
    console.error("[tiktoksearch2]", e.message);
    await m.react("☢");
    m.reply(te(m.prefix, m.command, m.pushName));
  }
}

export { config, handler };