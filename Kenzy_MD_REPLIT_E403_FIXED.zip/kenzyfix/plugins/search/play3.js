import { ytSearch, ytSearchVideo } from "../../src/scraper/ytsearch-safe.js";
import ytdl2 from "../../src/scraper/ytdl2.js";
import { A2UI, sendA2UIWidget } from "../../src/lib/ichigo-ui.js";
import te from "../../src/lib/ichigo-error.js";

const pluginConfig = {
  name: "play3",
  alias: ["play3dl"],
  category: "search",
  description: "Cari & download lagu YouTube pakai kartu interaktif A2UI + quick-reply",
  usage: ".play3 <judul lagu>",
  example: ".play3 komang",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 15,
  energi: 1,
  isEnabled: true,
};

const DOWNLOAD_TIMEOUT_MS = 25_000;
const MAX_RETRIES = 1;

const DEFAULT_VIDEO_QUALITY = "480";

function toSmallCaps(text) {
  const smallCaps = {
    a: "ᴀ", b: "ʙ", c: "ᴄ", d: "ᴅ", e: "ᴇ", f: "ꜰ", g: "ɢ", h: "ʜ", i: "ɪ", j: "ᴊ",
    k: "ᴋ", l: "ʟ", m: "ᴍ", n: "ɴ", o: "ᴏ", p: "ᴘ", q: "ǫ", r: "ʀ", s: "s", t: "ᴛ",
    u: "ᴜ", v: "ᴠ", w: "ᴡ", x: "x", y: "ʏ", z: "ᴢ",
  };
  return text
    .toLowerCase()
    .split("")
    .map((c) => smallCaps[c] || c)
    .join("");
}

function withTimeout(promiseFactory, ms) {
  const controller = new AbortController();

  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      controller.abort();
      reject(new Error("TIMEOUT"));
    }, ms);

    promiseFactory(controller.signal)
      .then((res) => {
        clearTimeout(timer);
        resolve(res);
      })
      .catch((err) => {
        clearTimeout(timer);
        reject(err);
      });
  });
}

async function withRetry(fn, { retries = MAX_RETRIES, timeoutMs = DOWNLOAD_TIMEOUT_MS } = {}) {
  let lastErr;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await withTimeout(fn, timeoutMs);
    } catch (err) {
      lastErr = err;
      const isTimeout = err?.message === "TIMEOUT";
      if (!isTimeout || attempt === retries) throw err;
      
      continue;
    }
  }
  throw lastErr;
}

async function getAudioDownload(url) {
  const result = await withRetry((signal) => ytdl2(url, "mp3", { signal }));
  if (result?.status && result?.download) {
    return { download: result.download, title: result.title };
  }
  throw new Error(result?.mess || "Gagal mendapatkan link download audio");
}

async function getVideoDownload(url) {
  const result = await withRetry((signal) => ytdl2(url, DEFAULT_VIDEO_QUALITY, { signal }));
  if (result?.status && result?.download) {
    return { download: result.download, title: result.title };
  }
  throw new Error(result?.mess || "Gagal mendapatkan link download video");
}

const isValidVideoId = (id) => /^[a-zA-Z0-9_-]{10,12}$/.test(id);

async function handleDownload(m, sock, url, format) {
  await m.react("🕕");
  try {
    if (format === "mp4") {
      const result = await getVideoDownload(url);
      await sock.sendMedia(m.chat, result.download, null, m, {
        type: "video",
        fileName: `${result.title || "video"}.mp4`,
      });
    } else {
      const result = await getAudioDownload(url);
      await sock.sendMedia(m.chat, result.download, null, m, {
        type: "audio",
        mimetype: "audio/mpeg",
        ptt: false,
        fileName: `${result.title || "audio"}.mp3`,
      });
    }

    await m.react("✅");
  } catch (e) {
    console.error("[PLAY3DL]", e);
    await m.react("☢");

    if (e?.message === "TIMEOUT") {
      m.reply(
        "⏰ *Server YouTube lagi lemot/timeout.*\n" +
          "Udah dicoba ulang otomatis tapi tetap gagal. Coba lagi beberapa saat lagi ya."
      );
    } else {
      m.reply(te(m.prefix, m.command, m.pushName));
    }
  }
}

async function handleSearch(m, sock, query) {
  await m.react("🕕");
  try {
    const search = await ytSearch(query);
    if (!search?.videos?.length) {
      await m.react("☢");
      return m.reply("❌ *Lagu tidak ditemukan di YouTube.*");
    }
    const video = search.videos[0];
    const prefix = m.prefix || ".";

    const ui = new A2UI();
    const thumb = ui.image(video.thumbnail, { variant: "header", fit: "contain" });
    const title = ui.text(video.title, { variant: "h1" });
    const info = ui.text(`${video.author.name} ✦ ${video.duration.timestamp}`, { variant: "caption" });
    const card = ui.card(ui.column([thumb, title, info]));

    ui.root([card]);

    const viewsFmt = video.views ? video.views.toLocaleString("en-US") : "N/A";
    const uploadedAgo = video.ago || "N/A";
    const footerLines = [
      `✦ ${toSmallCaps("author".padEnd(8))} : ${video.author.name}`,
      `✦ ${toSmallCaps("duration".padEnd(8))} : ${video.duration.timestamp}`,
      `✦ ${toSmallCaps("views".padEnd(8))} : ${viewsFmt}`,
      `✦ ${toSmallCaps("uploaded".padEnd(8))} : ${toSmallCaps(uploadedAgo)}`,
    ];
    const border = "─".repeat(8);
    const footerText = [
      `╭⌬${border}⌬`,
      ...footerLines.map((l) => `│ ${l}`),
      `╰⌬${border}⌬`,
    ].join("\n");

    await sendA2UIWidget(sock, m.chat, {
      a2ui: ui,
      bodyText: video.title,
      footer: footerText,
      buttons: [
        {
          name: "quick_reply",
          params: {
            display_text: "🎧 Download MP3",
            id: `${prefix}play3dl mp3 ${video.videoId}`,
          },
        },
        {
          name: "quick_reply",
          params: {
            display_text: "🎬 Download Video",
            id: `${prefix}play3dl mp4 ${video.videoId}`,
          },
        },
      ],
      contextInfo: { expiration: 7776000 },
    });

    await m.react("✅");
  } catch (e) {
    console.error("[PLAY3]", e);
    await m.react("☢");
    m.reply(te(m.prefix, m.command, m.pushName));
  }
}

async function handler(m, { sock }) {
  const isDownloadStep = m.command === "play3dl";
  const rawArg = m.args.join(" ").trim();

  if (isDownloadStep) {
    let format = "mp3";
    let arg = rawArg;
    const firstWord = rawArg.split(" ")[0]?.toLowerCase();
    if (firstWord === "mp3" || firstWord === "mp4") {
      format = firstWord;
      arg = rawArg.slice(firstWord.length).trim();
    }

    if (!arg || !isValidVideoId(arg)) {
      return m.reply("❌ ID video YouTube tidak valid.");
    }
    const videoUrl = `https://youtube.com/watch?v=${arg}`;
    return handleDownload(m, sock, videoUrl, format);
  }

  if (!rawArg) {
    return m.reply(
      `🎵 *Play3*\n\n` +
        `> Cari & download lagu YouTube pakai kartu interaktif\n\n` +
        `*PENGGUNAAN:*\n` +
        `> *${m.prefix}play3 <judul lagu>*\n\n` +
        `*CONTOH:*\n` +
        `> *${m.prefix}play3 komang*`
    );
  }

  return handleSearch(m, sock, rawArg);
}

export { pluginConfig as config, handler };